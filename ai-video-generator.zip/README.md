# 🎬 AI Video Generator

A full-stack AI-powered video generation platform built with Next.js 14, FastAPI, and PostgreSQL.

## ✨ Features

- **Authentication** — JWT-based login/signup with password reset, admin accounts, and role-based access
- **Dashboard** — Modern dark-mode UI with stats, quick actions, and activity feeds
- **AI Video Generation** — Text-to-video, image-to-video, and video-to-video generation
- **Prompt Studio** — Prompt enhancement, auto-generation, history tracking, and favorites
- **AI Script Writer** — Story, scene, and dialogue generation with full scene breakdowns
- **Character System** — Create and manage AI characters with consistency data
- **Voice AI** — Voice generation with profiles, speed/pitch controls
- **Video Editor** — Timeline editor with tracks, effects, transitions, and subtitles
- **Project Management** — Save, edit, export, and track project history
- **Settings** — User profile, API key management, security settings, theme toggle

## 🚀 Quick Start

### One-Command Deploy
```bash
docker-compose up
```

### Local Development
```bash
# Backend
cd backend && pip install -r requirements.txt && uvicorn main:app --reload --port 8000

# Frontend
cd frontend && npm install && npm run dev
```

### Default Admin
- Email: admin@aivideogen.com
- Password: admin123

## 📂 Structure
- `backend/` — FastAPI (Python) with PostgreSQL, JWT auth, 10 route modules
- `frontend/` — Next.js 14 (TypeScript) with TailwindCSS, 12 pages
- `docker-compose.yml` — Full-stack Docker deployment
- `.env.example` — Configuration template

## 🔌 API Docs
Visit http://localhost:8000/docs when running.

## 🛠️ Tech Stack
Next.js 14 | FastAPI | PostgreSQL | TailwindCSS | Docker | TypeScript | JWT | SQLAlchemy
