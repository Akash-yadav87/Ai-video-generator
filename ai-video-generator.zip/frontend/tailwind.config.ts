import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT: "#6366f1", 50: "#eef2ff", 100: "#e0e7ff", 200: "#c7d2fe", 300: "#a5b4fc", 400: "#818cf8", 500: "#6366f1", 600: "#4f46e5", 700: "#4338ca", 800: "#3730a3", 900: "#312e81" },
        surface: { DEFAULT: "#0f0f23", 50: "#1a1a2e", 100: "#16213e", 200: "#0f3460", 300: "#1a1a3e", 400: "#1e1e3a", 500: "#252545", 600: "#2d2d50", 700: "#35355a", 800: "#3d3d65", 900: "#454570" },
        accent: { DEFAULT: "#06d6a0", light: "#118ab2", dark: "#073b4c" },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Fira Code", "monospace"],
      },
      animation: {
        "glow-pulse": "glow-pulse 2s ease-in-out infinite alternate",
        "slide-up": "slide-up 0.3s ease-out",
        "slide-down": "slide-down 0.3s ease-out",
        fadeIn: "fadeIn 0.5s ease-in-out",
        shimmer: "shimmer 2s infinite linear",
      },
      keyframes: {
        "glow-pulse": { "0%": { boxShadow: "0 0 20px rgba(99,102,241,0.3)" }, "100%": { boxShadow: "0 0 40px rgba(99,102,241,0.6)" } },
        "slide-up": { "0%": { transform: "translateY(10px)", opacity: "0" }, "100%": { transform: "translateY(0)", opacity: "1" } },
        "slide-down": { "0%": { transform: "translateY(-10px)", opacity: "0" }, "100%": { transform: "translateY(0)", opacity: "1" } },
        fadeIn: { "0%": { opacity: "0" }, "100%": { opacity: "1" } },
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } },
      },
    },
  },
  plugins: [],
};

export default config;