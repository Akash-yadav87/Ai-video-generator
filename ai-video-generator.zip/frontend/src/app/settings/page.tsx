'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import {
  FiSettings, FiUser, FiKey, FiShield, FiBell, FiSun, FiMoon,
  FiSave, FiAlertCircle, FiCheckCircle, FiZap,
} from 'react-icons/fi';

export default function SettingsPage() {
  const { user, isLoading } = useAuth();
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const [tab, setTab] = useState<'profile' | 'api' | 'security' | 'notifications'>('profile');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Profile
  const [fullName, setFullName] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');

  // Security
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');

  // API Keys
  const [openaiKey, setOpenaiKey] = useState('');
  const [stabilityKey, setStabilityKey] = useState('');
  const [elevenlabsKey, setElevenlabsKey] = useState('');

  // Notifications
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [generationNotifs, setGenerationNotifs] = useState(true);
  const [marketingNotifs, setMarketingNotifs] = useState(false);

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) {
      setFullName(user.full_name || '');
      api.getSettings().then(s => {
        if (s.api_keys) {
          setOpenaiKey((s.api_keys as Record<string, string>).openai || '');
          setStabilityKey((s.api_keys as Record<string, string>).stability || '');
          setElevenlabsKey((s.api_keys as Record<string, string>).elevenlabs || '');
        }
      }).catch(() => {});
    }
  }, [user, isLoading, router]);

  const showMsg = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleUpdateProfile = async () => {
    try {
      await api.request('/auth/profile', { method: 'PUT', body: { full_name: fullName } } as Parameters<typeof api.request>[1]);
      showMsg('success', 'Profile updated');
    } catch { showMsg('error', 'Update failed'); }
  };

  const handleChangePassword = async () => {
    if (newPw !== confirmPw) { showMsg('error', 'Passwords do not match'); return; }
    try {
      await api.changePassword(currentPw, newPw);
      showMsg('success', 'Password changed');
      setCurrentPw(''); setNewPw(''); setConfirmPw('');
    } catch (err: unknown) { showMsg('error', err instanceof Error ? err.message : 'Failed'); }
  };

  const handleSaveApiKeys = async () => {
    try {
      await api.updateApiKeys({ openai: openaiKey, stability: stabilityKey, elevenlabs: elevenlabsKey });
      showMsg('success', 'API keys saved');
    } catch { showMsg('error', 'Failed to save API keys'); }
  };

  if (isLoading || !user) {
    return <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]"><FiSettings className="animate-pulse text-primary" size={32} /></div>;
  }

  const tabs = [
    { id: 'profile', label: 'Profile', icon: FiUser },
    { id: 'api', label: 'API Settings', icon: FiKey },
    { id: 'security', label: 'Security', icon: FiShield },
    { id: 'notifications', label: 'Notifications', icon: FiBell },
  ];

  return (
    <DashboardLayout>
      <h1 className="text-3xl font-bold mb-6">Settings</h1>

      {message && (
        <div className={`mb-4 flex items-center gap-2 p-3 rounded-lg text-sm animate-slide-down ${message.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-400' : 'bg-red-500/10 border border-red-500/30 text-red-400'}`}>
          {message.type === 'success' ? <FiCheckCircle size={16} /> : <FiAlertCircle size={16} />}
          {message.text}
        </div>
      )}

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Side tabs */}
        <div className="lg:col-span-1 space-y-1">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.id}
                onClick={() => setTab(t.id as typeof tab)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${tab === t.id ? 'bg-primary/15 text-primary border border-primary/30' : 'text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)]'}`}
              >
                <Icon size={18} /> {t.label}
              </button>
            );
          })}

          {/* Theme toggle */}
          <div className="p-4 mt-4 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)]">
            <p className="text-sm font-medium mb-3">Appearance</p>
            <div className="flex gap-2">
              <button
                onClick={() => setTheme('dark')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm border transition-all ${theme === 'dark' ? 'bg-primary/15 border-primary text-primary' : 'border-[var(--border-color)] text-[var(--text-secondary)]'}`}
              >
                <FiMoon size={14} /> Dark
              </button>
              <button
                onClick={() => setTheme('light')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm border transition-all ${theme === 'light' ? 'bg-primary/15 border-primary text-primary' : 'border-[var(--border-color)] text-[var(--text-secondary)]'}`}
              >
                <FiSun size={14} /> Light
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          {tab === 'profile' && (
            <div className="card">
              <h2 className="font-semibold mb-4 flex items-center gap-2"><FiUser size={18} className="text-primary" /> Profile Information</h2>
              <div className="space-y-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-xl bg-primary flex items-center justify-center text-white text-2xl font-bold">
                    {user.username[0].toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium">{user.username}</p>
                    <p className="text-sm text-[var(--text-muted)]">{user.email}</p>
                    <p className="text-xs text-[var(--text-muted)]">Role: {user.role}</p>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Full Name</label>
                  <input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Your full name" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Avatar URL</label>
                  <input value={avatarUrl} onChange={e => setAvatarUrl(e.target.value)} placeholder="https://..." />
                </div>
                <button onClick={handleUpdateProfile} className="btn btn-primary"><FiSave size={14} /> Save Changes</button>
              </div>
            </div>
          )}

          {tab === 'security' && (
            <div className="card">
              <h2 className="font-semibold mb-4 flex items-center gap-2"><FiShield size={18} className="text-primary" /> Change Password</h2>
              <div className="space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Current Password</label>
                  <input type="password" value={currentPw} onChange={e => setCurrentPw(e.target.value)} placeholder="••••••••" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">New Password</label>
                  <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="Min. 8 characters" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Confirm New Password</label>
                  <input type="password" value={confirmPw} onChange={e => setConfirmPw(e.target.value)} placeholder="••••••••" />
                </div>
                <button onClick={handleChangePassword} className="btn btn-primary"><FiSave size={14} /> Update Password</button>
              </div>
            </div>
          )}

          {tab === 'api' && (
            <div className="card">
              <h2 className="font-semibold mb-4 flex items-center gap-2"><FiKey size={18} className="text-primary" /> API Keys</h2>
              <p className="text-sm text-[var(--text-secondary)] mb-4">Your personal API keys for external AI services. These are stored securely.</p>
              <div className="space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium mb-1.5">OpenAI API Key</label>
                  <input type="password" value={openaiKey} onChange={e => setOpenaiKey(e.target.value)} placeholder="sk-..." />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Stability AI Key</label>
                  <input type="password" value={stabilityKey} onChange={e => setStabilityKey(e.target.value)} placeholder="sk-..." />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">ElevenLabs API Key</label>
                  <input type="password" value={elevenlabsKey} onChange={e => setElevenlabsKey(e.target.value)} placeholder="el-..." />
                </div>
                <button onClick={handleSaveApiKeys} className="btn btn-primary"><FiSave size={14} /> Save API Keys</button>
              </div>
            </div>
          )}

          {tab === 'notifications' && (
            <div className="card">
              <h2 className="font-semibold mb-4 flex items-center gap-2"><FiBell size={18} className="text-primary" /> Notification Preferences</h2>
              <div className="space-y-4 max-w-md">
                {[
                  { label: 'Email Notifications', desc: 'Receive important account updates via email', value: emailNotifs, setter: setEmailNotifs },
                  { label: 'Generation Alerts', desc: 'Get notified when video generation completes', value: generationNotifs, setter: setGenerationNotifs },
                  { label: 'Marketing Emails', desc: 'Receive tips, updates, and promotional content', value: marketingNotifs, setter: setMarketingNotifs },
                ].map(n => (
                  <label key={n.label} className="flex items-center justify-between p-3 rounded-lg bg-[var(--bg-tertiary)] cursor-pointer">
                    <div>
                      <p className="text-sm font-medium">{n.label}</p>
                      <p className="text-xs text-[var(--text-muted)]">{n.desc}</p>
                    </div>
                    <div className="relative">
                      <input type="checkbox" checked={n.value} onChange={e => n.setter(e.target.checked)} className="sr-only peer" />
                      <div className="w-10 h-6 rounded-full bg-[var(--border-color)] peer-checked:bg-primary transition-colors" />
                      <div className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white peer-checked:translate-x-4 transition-transform" />
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}