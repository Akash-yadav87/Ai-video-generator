'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import {
  FiFilm, FiScissors, FiType, FiLayers, FiMusic,
  FiPlus, FiPlay, FiSkipBack, FiSkipForward, FiSquare,
  FiChevronUp, FiChevronDown, FiSave, FiTrash2,
} from 'react-icons/fi';
import { formatDuration, cn } from '@/lib/utils';
import type { Project } from '@/types';

export default function VideoEditorPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(120);
  const [isPlaying, setIsPlaying] = useState(false);
  const [tracks, setTracks] = useState([
    { id: 'video-1', name: 'Main Video', type: 'video' as const, clips: [] },
    { id: 'audio-1', name: 'Background Music', type: 'audio' as const, clips: [] },
    { id: 'text-1', name: 'Subtitles', type: 'text' as const, clips: [] },
  ]);
  const [subtitles, setSubtitles] = useState<{ id: string; text: string; start: number; end: number }[]>([]);
  const [newSubtitle, setNewSubtitle] = useState('');
  const [showSubtitles, setShowSubtitles] = useState(false);

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) api.listProjects(1, 20).then(r => setProjects(r.items)).catch(() => {});
  }, [user, isLoading, router]);

  useEffect(() => {
    if (isPlaying) {
      const timer = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= totalDuration) { setIsPlaying(false); return totalDuration; }
          return prev + 0.1;
        });
      }, 100);
      return () => clearInterval(timer);
    }
  }, [isPlaying, totalDuration]);

  const addSubtitle = () => {
    if (!newSubtitle.trim()) return;
    setSubtitles(prev => [...prev, {
      id: Date.now().toString(),
      text: newSubtitle.trim(),
      start: currentTime,
      end: currentTime + 5,
    }]);
    setNewSubtitle('');
  };

  const removeSubtitle = (id: string) => setSubtitles(prev => prev.filter(s => s.id !== id));

  const timelinePercent = (currentTime / totalDuration) * 100;

  if (isLoading || !user) {
    return <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]"><FiFilm className="animate-pulse text-primary" size={32} /></div>;
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Video Editor</h1>
          <p className="text-[var(--text-secondary)]">Edit your videos with timeline, effects, and subtitles.</p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={selectedProject || ''}
            onChange={e => setSelectedProject(e.target.value || null)}
            className="w-48"
          >
            <option value="">Select project...</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
          </select>
          <button className="btn btn-secondary btn-sm"><FiSave size={14} /> Save</button>
        </div>
      </div>

      {/* Canvas preview area */}
      <div className="card mb-6">
        <div className="aspect-video bg-[var(--bg-primary)] rounded-lg flex items-center justify-center border border-[var(--border-color)]">
          <div className="text-center">
            <FiFilm size={64} className="mx-auto mb-4 text-[var(--text-muted)] opacity-40" />
            <p className="text-lg font-medium text-[var(--text-secondary)]">Video Preview Canvas</p>
            <p className="text-sm text-[var(--text-muted)]">Time: {formatDuration(currentTime)} / {formatDuration(totalDuration)}</p>
            {subtitles.length > 0 && (
              <div className="mt-4 bg-black/70 text-white px-4 py-2 rounded max-w-lg mx-auto">
                {subtitles.find(s => currentTime >= s.start && currentTime <= s.end)?.text || ''}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Transport controls */}
      <div className="card mb-6">
        <div className="flex items-center justify-center gap-4">
          <button onClick={() => setCurrentTime(0)} className="p-2 rounded-lg hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)]">
            <FiSkipBack size={20} />
          </button>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-3 rounded-full bg-primary text-white hover:bg-primary/80 transition-colors"
          >
            {isPlaying ? <FiSquare size={20} /> : <FiPlay size={20} />}
          </button>
          <button onClick={() => setCurrentTime(totalDuration)} className="p-2 rounded-lg hover:bg-[var(--bg-tertiary)] text-[var(--text-secondary)]">
            <FiSkipForward size={20} />
          </button>
        </div>
      </div>

      {/* Timeline */}
      <div className="card mb-6">
        <h3 className="font-semibold mb-3 flex items-center gap-2"><FiLayers size={18} className="text-primary" /> Timeline</h3>

        {/* Timeline ruler */}
        <div className="relative h-8 bg-[var(--bg-tertiary)] rounded-lg mb-2 cursor-pointer"
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const pct = (e.clientX - rect.left) / rect.width;
            setCurrentTime(pct * totalDuration);
          }}
        >
          <div className="absolute top-0 left-0 h-full bg-primary/20 rounded-l-lg" style={{ width: `${timelinePercent}%` }} />
          <div className="absolute top-0 h-full w-0.5 bg-primary" style={{ left: `${timelinePercent}%` }}>
            <FiChevronDown size={12} className="absolute -top-3 -left-1.5 text-primary" />
          </div>
          {/* Time markers */}
          {Array.from({ length: 11 }, (_, i) => (
            <div key={i} className="absolute bottom-0 text-[10px] text-[var(--text-muted)]" style={{ left: `${(i / 10) * 100}%` }}>
              {formatDuration((i / 10) * totalDuration)}
            </div>
          ))}
        </div>

        {/* Tracks */}
        <div className="space-y-2">
          {tracks.map(track => (
            <div key={track.id} className="flex items-center gap-3 p-2 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)]">
              <div className="w-8 h-8 rounded bg-[var(--bg-primary)] flex items-center justify-center flex-shrink-0">
                {track.type === 'video' && <FiFilm size={14} className="text-blue-400" />}
                {track.type === 'audio' && <FiMusic size={14} className="text-green-400" />}
                {track.type === 'text' && <FiType size={14} className="text-yellow-400" />}
              </div>
              <span className="text-sm w-24 flex-shrink-0">{track.name}</span>
              <div className="flex-1 h-8 bg-[var(--bg-primary)] rounded relative">
                {/* Track visualization bar */}
                <div className="absolute inset-0 rounded opacity-40 bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
                {track.clips.length === 0 && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[10px] text-[var(--text-muted)]">Empty track</span>
                  </div>
                )}
              </div>
              <button className="p-1 rounded hover:bg-[var(--bg-primary)] text-[var(--text-muted)]"><FiTrash2 size={12} /></button>
            </div>
          ))}
        </div>

        <button className="btn btn-secondary btn-sm mt-3"><FiPlus size={14} /> Add Track</button>
      </div>

      {/* Subtitles */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold flex items-center gap-2"><FiType size={18} className="text-yellow-400" /> Subtitles</h3>
          <button onClick={() => setShowSubtitles(!showSubtitles)} className="btn btn-ghost btn-sm">
            {showSubtitles ? <FiChevronUp size={14} /> : <FiChevronDown size={14} />} {subtitles.length} subtitles
          </button>
        </div>

        {showSubtitles && (
          <>
            <div className="flex gap-2 mb-4">
              <input value={newSubtitle} onChange={e => setNewSubtitle(e.target.value)} placeholder="Enter subtitle text..." className="flex-1" onKeyDown={e => e.key === 'Enter' && addSubtitle()} />
              <button onClick={addSubtitle} className="btn btn-primary btn-sm"><FiPlus size={14} /> Add at {formatDuration(currentTime)}</button>
            </div>
            {subtitles.length === 0 ? (
              <p className="text-sm text-[var(--text-muted)] text-center py-4">No subtitles added yet.</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {subtitles.map(s => (
                  <div key={s.id} className="flex items-center gap-3 p-2 rounded-lg bg-[var(--bg-tertiary)]">
                    <span className="text-xs text-[var(--text-muted)] w-24">{formatDuration(s.start)} - {formatDuration(s.end)}</span>
                    <span className="flex-1 text-sm">{s.text}</span>
                    <button onClick={() => removeSubtitle(s.id)} className="text-red-400 hover:bg-red-500/10 p-1 rounded"><FiTrash2 size={14} /></button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}