'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import { FiMic, FiPlay, FiVolume2, FiPlus, FiTrash2, FiSettings, FiZap } from 'react-icons/fi';
import type { VoiceProfile } from '@/types';

export default function VoiceAIPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [tab, setTab] = useState<'generate' | 'profiles'>('generate');
  const [profiles, setProfiles] = useState<VoiceProfile[]>([]);
  const [text, setText] = useState('');
  const [voiceId, setVoiceId] = useState('');
  const [speed, setSpeed] = useState(1.0);
  const [pitch, setPitch] = useState(1.0);
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<{ audio_url: string; duration_seconds: number } | null>(null);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [profileName, setProfileName] = useState('');

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) loadProfiles();
  }, [user, isLoading, router]);

  const loadProfiles = async () => {
    try { setProfiles(await api.listVoiceProfiles()); } catch {}
  };

  const handleGenerate = async () => {
    if (!text.trim()) return;
    setGenerating(true);
    try {
      const res = await api.generateVoice(text, voiceId || undefined, 'elevenlabs', speed, pitch);
      setResult(res);
    } catch {} finally { setGenerating(false); }
  };

  const handleCreateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim()) return;
    try {
      await api.request('/voice/profiles', {
        method: 'POST', body: { name: profileName, voice_id: voiceId, provider: 'elevenlabs' },
      } as Parameters<typeof api.request>[1]);
      setShowProfileForm(false);
      setProfileName('');
      await loadProfiles();
    } catch {}
  };

  if (isLoading || !user) {
    return <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]"><FiMic className="animate-pulse text-primary" size={32} /></div>;
  }

  return (
    <DashboardLayout>
      <h1 className="text-3xl font-bold mb-2">Voice AI</h1>
      <p className="text-[var(--text-secondary)] mb-6">Generate voice narration and manage voice profiles.</p>

      <div className="flex gap-1 bg-[var(--bg-secondary)] rounded-xl p-1 mb-6 border border-[var(--border-color)] w-fit">
        {[
          { id: 'generate', label: 'Voice Generation', icon: FiMic },
          { id: 'profiles', label: 'Voice Profiles', icon: FiSettings },
        ].map(t => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id as typeof tab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === t.id ? 'bg-primary text-white' : 'text-[var(--text-secondary)]'}`}>
              <Icon size={16} /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'generate' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="font-semibold mb-4">Generate Voice</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Text to Speak</label>
                <textarea value={text} onChange={e => setText(e.target.value)} rows={5} placeholder="Enter the text you want the AI to speak..." />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Voice ID (optional)</label>
                <input value={voiceId} onChange={e => setVoiceId(e.target.value)} placeholder="Leave empty for default" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Speed: {speed}x</label>
                  <input type="range" min="0.5" max="2" step="0.1" value={speed} onChange={e => setSpeed(Number(e.target.value))} className="w-full" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Pitch: {pitch}</label>
                  <input type="range" min="0.5" max="2" step="0.1" value={pitch} onChange={e => setPitch(Number(e.target.value))} className="w-full" />
                </div>
              </div>
              <button onClick={handleGenerate} disabled={generating || !text} className="btn btn-primary w-full">
                {generating ? 'Generating...' : <><FiMic size={16} /> Generate Voice</>}
              </button>
            </div>
          </div>
          <div className="card">
            <h2 className="font-semibold mb-4">Result</h2>
            {result ? (
              <div className="text-center py-8">
                <div className="w-20 h-20 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-4">
                  <FiVolume2 size={36} className="text-primary" />
                </div>
                <p className="font-medium mb-1">Voice Generated</p>
                <p className="text-sm text-[var(--text-muted)] mb-4">Duration: {result.duration_seconds.toFixed(1)}s</p>
                <div className="flex gap-2 justify-center">
                  <a href={result.audio_url} target="_blank" className="btn btn-primary"><FiPlay size={14} /> Play</a>
                  <a href={result.audio_url} download className="btn btn-secondary"><FiZap size={14} /> Download</a>
                </div>
                <p className="text-xs text-[var(--text-muted)] mt-4">Audio URL: {result.audio_url}</p>
              </div>
            ) : (
              <div className="text-center py-12 text-[var(--text-muted)]">
                <FiMic size={48} className="mx-auto mb-4 opacity-30" />
                <p>Enter text and generate voice audio.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'profiles' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Saved Voice Profiles</h2>
            <button onClick={() => setShowProfileForm(!showProfileForm)} className="btn btn-primary btn-sm"><FiPlus size={14} /> New Profile</button>
          </div>
          {showProfileForm && (
            <form onSubmit={handleCreateProfile} className="card mb-4 flex items-end gap-3 animate-slide-down">
              <div className="flex-1">
                <label className="block text-sm font-medium mb-1.5">Profile Name</label>
                <input value={profileName} onChange={e => setProfileName(e.target.value)} placeholder="My Voice Profile" required />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium mb-1.5">Voice ID</label>
                <input value={voiceId} onChange={e => setVoiceId(e.target.value)} placeholder="Optional" />
              </div>
              <button type="submit" className="btn btn-primary">Create</button>
              <button type="button" onClick={() => setShowProfileForm(false)} className="btn btn-secondary">Cancel</button>
            </form>
          )}
          {profiles.length === 0 ? (
            <div className="text-center py-12 text-[var(--text-muted)]"><FiSettings size={48} className="mx-auto mb-4 opacity-30" /><p>No voice profiles.</p></div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {profiles.map(p => (
                <div key={p.id} className="card">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center"><FiMic className="text-primary" size={18} /></div>
                    <div>
                      <p className="font-medium text-sm">{p.name}</p>
                      <p className="text-xs text-[var(--text-muted)]">{p.provider}</p>
                    </div>
                  </div>
                  <p className="text-xs text-[var(--text-muted)]">Voice ID: {p.voice_id || 'N/A'}</p>
                  <div className="flex justify-end mt-3">
                    <button onClick={() => { /* delete */ }} className="btn btn-ghost btn-sm text-red-400"><FiTrash2 size={14} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  );
}