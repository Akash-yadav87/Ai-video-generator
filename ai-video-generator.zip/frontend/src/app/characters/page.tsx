'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import { FiUsers, FiPlus, FiTrash2, FiEdit3, FiUser, FiMic, FiImage, FiEye } from 'react-icons/fi';
import { formatDate, getInitials, cn } from '@/lib/utils';
import type { Character } from '@/types';

export default function CharactersPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [characters, setCharacters] = useState<Character[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [appearance, setAppearance] = useState('');
  const [personality, setPersonality] = useState('');
  const [voiceId, setVoiceId] = useState('');

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) loadCharacters();
  }, [user, isLoading, router]);

  const loadCharacters = async () => {
    try { const r = await api.listCharacters(1, 50); setCharacters(r.items); } catch {}
  };

  const resetForm = () => { setName(''); setDesc(''); setAppearance(''); setPersonality(''); setVoiceId(''); setEditingId(null); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      if (editingId) {
        await api.updateCharacter(editingId, { name, description: desc, appearance, personality, voice_id: voiceId });
      } else {
        await api.createCharacter({ name, description: desc, appearance, personality, voice_id: voiceId });
      }
      setShowForm(false);
      resetForm();
      await loadCharacters();
    } catch {}
  };

  const handleDelete = async (id: string) => {
    try { await api.deleteCharacter(id); setCharacters(prev => prev.filter(c => c.id !== id)); } catch {}
  };

  if (isLoading || !user) {
    return <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]"><FiUsers className="animate-pulse text-primary" size={32} /></div>;
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Characters</h1>
          <p className="text-[var(--text-secondary)]">Create and manage AI characters with consistent identity.</p>
        </div>
        <button onClick={() => { resetForm(); setShowForm(!showForm); }} className="btn btn-primary">
          <FiPlus size={16} /> {showForm ? 'Cancel' : 'New Character'}
        </button>
      </div>

      {showForm && (
        <div className="card mb-6 animate-slide-down">
          <h2 className="font-semibold mb-4">{editingId ? 'Edit Character' : 'Create Character'}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Name</label>
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Character name" required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Voice ID</label>
                <input value={voiceId} onChange={e => setVoiceId(e.target.value)} placeholder="Optional voice ID" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Description</label>
              <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} placeholder="Backstory and description..." />
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Appearance</label>
                <textarea value={appearance} onChange={e => setAppearance(e.target.value)} rows={3} placeholder="Physical appearance details..." />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Personality</label>
                <textarea value={personality} onChange={e => setPersonality(e.target.value)} rows={3} placeholder="Personality traits..." />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => { setShowForm(false); resetForm(); }} className="btn btn-secondary">Cancel</button>
              <button type="submit" className="btn btn-primary">{editingId ? 'Update' : 'Create'} Character</button>
            </div>
          </form>
        </div>
      )}

      {characters.length === 0 ? (
        <div className="text-center py-16 text-[var(--text-muted)]">
          <FiUsers size={56} className="mx-auto mb-4 opacity-30" />
          <p className="text-lg mb-4">No characters created yet.</p>
          <button onClick={() => setShowForm(true)} className="btn btn-primary"><FiPlus size={16} /> Create Your First Character</button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {characters.map(c => (
            <div key={c.id} className="card group">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    {c.avatar_url ? (
                      <img src={c.avatar_url} alt={c.name} className="w-full h-full rounded-xl object-cover" />
                    ) : (
                      <span className="text-primary font-bold text-lg">{getInitials(c.name)}</span>
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">{c.name}</h3>
                    {c.voice_id && <span className="text-xs text-[var(--text-muted)] flex items-center gap-1"><FiMic size={10} /> Voice ready</span>}
                  </div>
                </div>
                <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => { setEditingId(c.id); setName(c.name); setDesc(c.description || ''); setAppearance(c.appearance || ''); setPersonality(c.personality || ''); setVoiceId(c.voice_id || ''); setShowForm(true); }} className="p-1.5 rounded hover:bg-[var(--bg-tertiary)]">
                    <FiEdit3 size={14} className="text-[var(--text-muted)]" />
                  </button>
                  <button onClick={() => handleDelete(c.id)} className="p-1.5 rounded hover:bg-red-500/10">
                    <FiTrash2 size={14} className="text-red-400" />
                  </button>
                </div>
              </div>
              {c.description && <p className="text-sm text-[var(--text-secondary)] line-clamp-2 mb-2">{c.description}</p>}
              <div className="flex flex-wrap gap-1">
                {c.appearance && <span className="text-xs px-2 py-0.5 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border-color)]">Appearance defined</span>}
                {c.personality && <span className="text-xs px-2 py-0.5 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border-color)]">Personality defined</span>}
                {c.is_public && <span className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent border border-accent/20">Public</span>}
              </div>
              <p className="text-xs text-[var(--text-muted)] mt-3">{formatDate(c.created_at)}</p>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}