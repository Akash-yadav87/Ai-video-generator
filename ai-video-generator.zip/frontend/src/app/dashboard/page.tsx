'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import {
  FiVideo, FiEdit3, FiFileText, FiUsers,
  FiMic, FiTrendingUp, FiClock, FiPlay, FiFolder,
  FiPlus, FiArrowRight, FiZap,
} from 'react-icons/fi';
import { formatDate, statusColor } from '@/lib/utils';
import type { VideoGeneration, Project, Script } from '@/types';
import Link from 'next/link';

export default function DashboardPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [recentGenerations, setRecentGenerations] = useState<VideoGeneration[]>([]);
  const [recentProjects, setRecentProjects] = useState<Project[]>([]);
  const [recentScripts, setRecentScripts] = useState<Script[]>([]);
  const [stats, setStats] = useState({ generations: 0, projects: 0, scripts: 0, characters: 0 });

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (!user) return;

    Promise.all([
      api.listGenerations(1, 5),
      api.listProjects(1, 5),
      api.listScripts(1, 5),
      api.listCharacters(1, 5),
    ]).then(([gens, projs, scrs, chars]) => {
      setRecentGenerations(gens.items);
      setRecentProjects(projs.items);
      setRecentScripts(scrs.items);
      setStats({
        generations: gens.total,
        projects: projs.total,
        scripts: scrs.total,
        characters: chars.total,
      });
    }).catch(() => {});
  }, [user, isLoading, router]);

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]">
        <div className="text-center">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-4 animate-pulse">
            <FiZap className="text-white" size={20} />
          </div>
          <p className="text-[var(--text-muted)]">Loading...</p>
        </div>
      </div>
    );
  }

  const quickActions = [
    { label: 'Text to Video', icon: FiVideo, href: '/video-generator', color: 'text-primary', bg: 'bg-primary/15' },
    { label: 'Prompt Studio', icon: FiEdit3, href: '/prompt-studio', color: 'text-accent', bg: 'bg-accent/15' },
    { label: 'Script Writer', icon: FiFileText, href: '/script-writer', color: 'text-yellow-400', bg: 'bg-yellow-500/15' },
    { label: 'Characters', icon: FiUsers, href: '/characters', color: 'text-purple-400', bg: 'bg-purple-500/15' },
    { label: 'Voice AI', icon: FiMic, href: '/voice-ai', color: 'text-pink-400', bg: 'bg-pink-500/15' },
    { label: 'New Project', icon: FiFolder, href: '/projects', color: 'text-blue-400', bg: 'bg-blue-500/15' },
  ];

  const statCards = [
    { label: 'Total Generations', value: stats.generations, icon: FiVideo, color: 'primary' },
    { label: 'Projects', value: stats.projects, icon: FiFolder, color: 'accent' },
    { label: 'Scripts', value: stats.scripts, icon: FiFileText, color: 'yellow-400' },
    { label: 'Characters', value: stats.characters, icon: FiUsers, color: 'purple-400' },
  ];

  return (
    <DashboardLayout>
      {/* Welcome */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-1">
          Welcome back, <span className="gradient-text">{user.full_name || user.username}</span>
        </h1>
        <p className="text-[var(--text-secondary)]">Here&apos;s what&apos;s happening with your AI video studio.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card flex items-center gap-4">
              <div className={`w-11 h-11 rounded-xl bg-${s.color}/15 flex items-center justify-center`}>
                <Icon className={`text-${s.color}`} size={22} />
              </div>
              <div>
                <p className="text-sm text-[var(--text-muted)]">{s.label}</p>
                <p className="text-2xl font-bold">{s.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <div className="card lg:col-span-1">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <FiPlay size={18} className="text-primary" /> Quick Actions
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Link
                  key={action.label}
                  href={action.href}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border border-[var(--border-color)] hover:border-primary/50 transition-all group bg-[var(--bg-tertiary)]`}
                >
                  <div className={`w-10 h-10 rounded-lg ${action.bg} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <Icon className={action.color} size={20} />
                  </div>
                  <span className="text-xs font-medium text-center text-[var(--text-secondary)]">{action.label}</span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Recent Generations */}
        <div className="card lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <FiTrendingUp size={18} className="text-primary" /> Recent Generations
            </h2>
            <Link href="/video-generator" className="btn btn-ghost btn-sm">
              View All <FiArrowRight size={14} />
            </Link>
          </div>
          {recentGenerations.length === 0 ? (
            <div className="text-center py-8 text-[var(--text-muted)]">
              <FiVideo size={36} className="mx-auto mb-3 opacity-40" />
              <p className="text-sm">No generations yet.</p>
              <Link href="/video-generator" className="btn btn-primary btn-sm mt-3">Generate Your First Video</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {recentGenerations.map((gen) => (
                <div key={gen.id} className="flex items-center gap-3 p-3 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)]">
                  <div className="w-16 h-10 rounded bg-[var(--bg-primary)] flex items-center justify-center flex-shrink-0">
                    <FiVideo size={18} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{gen.prompt.slice(0, 60)}...</p>
                    <p className="text-xs text-[var(--text-muted)]">{gen.generation_type} &bull; {formatDate(gen.created_at)}</p>
                  </div>
                  <span className={`badge ${statusColor(gen.status)}`}>{gen.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Projects */}
        <div className="card lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <FiFolder size={18} className="text-accent" /> Recent Projects
            </h2>
            <Link href="/projects" className="btn btn-ghost btn-sm">
              View All <FiArrowRight size={14} />
            </Link>
          </div>
          {recentProjects.length === 0 ? (
            <div className="text-center py-8 text-[var(--text-muted)]">
              <FiFolder size={36} className="mx-auto mb-3 opacity-40" />
              <p className="text-sm">No projects yet.</p>
              <Link href="/projects" className="btn btn-primary btn-sm mt-3">Create Project</Link>
            </div>
          ) : (
            <div className="space-y-2">
              {recentProjects.map((proj) => (
                <Link key={proj.id} href={`/projects`} className="flex items-center gap-3 p-3 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)] hover:border-primary/40 transition-all">
                  <div className="w-16 h-10 rounded bg-[var(--bg-primary)] flex items-center justify-center flex-shrink-0">
                    <FiFolder size={18} className="text-accent" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{proj.title}</p>
                    <p className="text-xs text-[var(--text-muted)]">{proj.project_type} &bull; {formatDate(proj.updated_at)}</p>
                  </div>
                  <span className={`badge ${statusColor(proj.status)}`}>{proj.status}</span>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Recent Scripts */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <FiFileText size={18} className="text-yellow-400" /> Scripts
            </h2>
            <Link href="/script-writer" className="btn btn-ghost btn-sm">
              <FiPlus size={14} />
            </Link>
          </div>
          {recentScripts.length === 0 ? (
            <div className="text-center py-8 text-[var(--text-muted)]">
              <FiFileText size={36} className="mx-auto mb-3 opacity-40" />
              <p className="text-sm">No scripts written.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentScripts.map((scr) => (
                <div key={scr.id} className="p-3 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)]">
                  <p className="text-sm font-medium">{scr.title}</p>
                  <p className="text-xs text-[var(--text-muted)]">{scr.genre || 'No genre'}</p>
                  <p className="text-xs text-[var(--text-muted)] mt-1">{formatDate(scr.created_at)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}