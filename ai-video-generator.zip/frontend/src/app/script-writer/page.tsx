'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import {
  FiFileText, FiZap, FiClock, FiPlus, FiTrash2, FiBookmark,
  FiPlay, FiUsers, FiMapPin, FiClock as FiClockIcon,
} from 'react-icons/fi';
import { formatDate } from '@/lib/utils';
import type { Script, Scene } from '@/types';

export default function ScriptWriterPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [tab, setTab] = useState<'generate' | 'history'>('generate');
  const [scripts, setScripts] = useState<Script[]>([]);

  // Generate form
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('drama');
  const [premise, setPremise] = useState('');
  const [numScenes, setNumScenes] = useState(5);
  const [includeDialogue, setIncludeDialogue] = useState(true);
  const [characterInput, setCharacterInput] = useState('');
  const [generating, setGenerating] = useState(false);
  const [currentScript, setCurrentScript] = useState<Script | null>(null);

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) api.listScripts(1, 20).then(r => setScripts(r.items)).catch(() => {});
  }, [user, isLoading, router]);

  const handleGenerate = async () => {
    if (!premise.trim() || !title.trim()) return;
    setGenerating(true);
    try {
      const chars = characterInput ? characterInput.split(',').map(c => c.trim()) : undefined;
      const result = await api.generateScript({
        title, genre, premise, num_scenes: numScenes, include_dialogue: includeDialogue,
        character_names: chars,
      });
      setCurrentScript(result);
      setScripts(prev => [result, ...prev]);
    } catch { /* silent */ } finally { setGenerating(false); }
  };

  if (isLoading || !user) {
    return <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]"><FiZap className="animate-pulse text-primary" size={32} /></div>;
  }

  return (
    <DashboardLayout>
      <h1 className="text-3xl font-bold mb-2">AI Script Writer</h1>
      <p className="text-[var(--text-secondary)] mb-6">Generate stories, scenes, and dialogue with AI.</p>

      <div className="flex gap-1 bg-[var(--bg-secondary)] rounded-xl p-1 mb-6 border border-[var(--border-color)] w-fit">
        {[
          { id: 'generate', label: 'Generate Script', icon: FiZap },
          { id: 'history', label: 'Script History', icon: FiClock },
        ].map(t => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id as typeof tab)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === t.id ? 'bg-primary text-white' : 'text-[var(--text-secondary)]'}`}>
              <Icon size={16} /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'generate' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="font-semibold mb-4">Script Generator</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Title</label>
                <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="My Awesome Script" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Genre</label>
                  <select value={genre} onChange={e => setGenre(e.target.value)}>
                    {['drama', 'comedy', 'thriller', 'horror', 'scifi', 'fantasy', 'romance', 'action'].map(g => <option key={g}>{g}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Scenes</label>
                  <select value={numScenes} onChange={e => setNumScenes(Number(e.target.value))}>
                    {[1,2,3,5,8,10,15].map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Premise</label>
                <textarea value={premise} onChange={e => setPremise(e.target.value)} rows={4} placeholder="Describe the story premise..." />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Characters (comma-separated)</label>
                <input type="text" value={characterInput} onChange={e => setCharacterInput(e.target.value)} placeholder="ALEX, JORDAN, SAM" />
              </div>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={includeDialogue} onChange={e => setIncludeDialogue(e.target.checked)} className="w-4 h-4" />
                Include Dialogue
              </label>
              <button onClick={handleGenerate} disabled={generating || !premise || !title} className="btn btn-primary w-full">
                {generating ? 'Writing Script...' : <><FiZap size={16} /> Generate Script</>}
              </button>
            </div>
          </div>

          {/* Script preview */}
          <div className="card">
            <h2 className="font-semibold mb-4">Script Preview</h2>
            {currentScript && currentScript.content.scenes ? (
              <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
                <div className="text-center mb-4 pb-4 border-b border-[var(--border-color)]">
                  <h3 className="text-xl font-bold">{currentScript.title}</h3>
                  <p className="text-sm text-[var(--text-secondary)]">{currentScript.genre} &bull; {currentScript.content.scenes.length} scenes</p>
                  <p className="text-sm italic mt-2">{currentScript.logline}</p>
                </div>
                {currentScript.content.scenes.map((scene: Scene) => (
                  <div key={scene.scene_number} className="p-4 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)]">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-sm font-bold text-primary">Scene {scene.scene_number}</span>
                      <span className="text-xs text-[var(--text-muted)] flex items-center gap-1"><FiMapPin size={12} /> {scene.location}</span>
                      <span className="text-xs text-[var(--text-muted)] flex items-center gap-1"><FiClockIcon size={12} /> {scene.time}</span>
                      <span className="badge bg-primary/10 text-primary text-xs">{scene.mood}</span>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)] mb-3 italic">{scene.description}</p>
                    {scene.dialogue && scene.dialogue.length > 0 && (
                      <div className="space-y-2">
                        {scene.dialogue.map((d, di) => (
                          <div key={di} className="flex items-start gap-2">
                            <span className="font-bold text-xs text-primary min-w-[60px] pt-0.5">{d.character}</span>
                            <div>
                              <p className="text-sm">{d.line}</p>
                              {d.direction && <span className="text-xs text-[var(--text-muted)] italic">{d.direction}</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-[var(--text-muted)]">
                <FiFileText size={48} className="mx-auto mb-4 opacity-30" />
                <p>Generate a script to see it here.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="card">
          <h2 className="font-semibold mb-4">Script History</h2>
          {scripts.length === 0 ? (
            <div className="text-center py-12 text-[var(--text-muted)]">
              <FiClock size={48} className="mx-auto mb-4 opacity-30" /><p>No scripts yet.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {scripts.map(s => (
                <div key={s.id} className="p-4 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)] flex items-center justify-between">
                  <div>
                    <p className="font-medium">{s.title}</p>
                    <div className="flex gap-2 mt-1 text-xs text-[var(--text-muted)]">
                      <span>{s.genre}</span>
                      <span>{s.content.scenes?.length || 0} scenes</span>
                      <span>{formatDate(s.created_at)}</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => setCurrentScript(s)} className="btn btn-ghost btn-sm"><FiPlay size={14} /> View</button>
                    <button className="btn btn-ghost btn-sm text-red-400"><FiTrash2 size={14} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </DashboardLayout>
  );
}