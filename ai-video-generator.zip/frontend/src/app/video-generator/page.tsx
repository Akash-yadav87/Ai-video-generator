'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import {
  FiVideo, FiImage, FiFilm, FiZap, FiPlay, FiClock,
  FiCheckCircle, FiLoader, FiAlertCircle, FiDownload, FiTrash2,
  FiRefreshCw, FiPlus,
} from 'react-icons/fi';
import { formatDate, statusColor, cn } from '@/lib/utils';
import type { VideoGeneration } from '@/types';

type GenType = 'text-to-video' | 'image-to-video' | 'video-to-video';

export default function VideoGeneratorPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [genType, setGenType] = useState<GenType>('text-to-video');
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [duration, setDuration] = useState(5);
  const [resolution, setResolution] = useState('1080p');
  const [generating, setGenerating] = useState(false);
  const [generations, setGenerations] = useState<VideoGeneration[]>([]);
  const [error, setError] = useState('');
  const [enhancedPrompt, setEnhancedPrompt] = useState('');

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) {
      api.listGenerations(1, 20).then(res => setGenerations(res.items)).catch(() => {});
    }
  }, [user, isLoading, router]);

  const handleGenerate = async () => {
    if (!prompt.trim()) { setError('Please enter a prompt'); return; }
    setError('');
    setGenerating(true);
    try {
      const result = await api.generateVideo({
        generation_type: genType, prompt: prompt.trim(),
        negative_prompt: negativePrompt || undefined,
        source_url: genType !== 'text-to-video' ? sourceUrl || undefined : undefined,
        duration, resolution,
      });
      setGenerations(prev => [result, ...prev]);
      setPrompt('');
      setEnhancedPrompt('');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleEnhance = async () => {
    if (!prompt.trim()) return;
    try {
      const res = await api.enhancePrompt(prompt.trim());
      setEnhancedPrompt(res.enhanced_prompt);
    } catch {
      // silent fail
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteGeneration(id);
      setGenerations(prev => prev.filter(g => g.id !== id));
    } catch { /* silent */ }
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]">
        <FiLoader className="animate-spin text-primary" size={32} />
      </div>
    );
  }

  const genTypes: { value: GenType; label: string; icon: React.ElementType }[] = [
    { value: 'text-to-video', label: 'Text to Video', icon: FiVideo },
    { value: 'image-to-video', label: 'Image to Video', icon: FiImage },
    { value: 'video-to-video', label: 'Video to Video', icon: FiFilm },
  ];

  return (
    <DashboardLayout>
      <h1 className="text-3xl font-bold mb-6">AI Video Generator</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Generation panel */}
        <div className="lg:col-span-1 space-y-6">
          <div className="card">
            <h2 className="font-semibold mb-4 flex items-center gap-2"><FiPlay size={18} className="text-primary" /> Generate Video</h2>

            {/* Type selector */}
            <div className="flex gap-1 bg-[var(--bg-tertiary)] rounded-lg p-1 mb-4">
              {genTypes.map((t) => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.value}
                    onClick={() => setGenType(t.value)}
                    className={cn(
                      'flex-1 flex items-center justify-center gap-1.5 py-2 rounded-md text-xs font-medium transition-all',
                      genType === t.value ? 'bg-primary text-white shadow' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]',
                    )}
                  >
                    <Icon size={14} /> {t.label}
                  </button>
                );
              })}
            </div>

            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm mb-4">
                <FiAlertCircle size={16} /> {error}
              </div>
            )}

            {/* Prompt */}
            <div className="space-y-3 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Prompt</label>
                <textarea
                  value={prompt}
                  onChange={e => setPrompt(e.target.value)}
                  placeholder="Describe the video you want to generate..."
                  rows={4}
                  className="resize-none"
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-[var(--text-muted)]">{prompt.length}/5000</span>
                  <button onClick={handleEnhance} className="text-xs text-primary hover:underline flex items-center gap-1">
                    <FiZap size={12} /> Enhance with AI
                  </button>
                </div>
              </div>

              {enhancedPrompt && (
                <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-sm">
                  <p className="text-xs text-primary font-medium mb-1">Enhanced Prompt:</p>
                  <p className="text-[var(--text-secondary)]">{enhancedPrompt}</p>
                  <button onClick={() => setPrompt(enhancedPrompt)} className="text-xs text-primary mt-1 hover:underline">Use this</button>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium mb-1.5">Negative Prompt</label>
                <input
                  type="text" value={negativePrompt}
                  onChange={e => setNegativePrompt(e.target.value)}
                  placeholder="What to avoid..."
                />
              </div>

              {genType !== 'text-to-video' && (
                <div>
                  <label className="block text-sm font-medium mb-1.5">Source URL</label>
                  <input
                    type="text" value={sourceUrl}
                    onChange={e => setSourceUrl(e.target.value)}
                    placeholder="https://..."
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-1.5">Duration (s)</label>
                  <select value={duration} onChange={e => setDuration(Number(e.target.value))}>
                    {[3, 5, 10, 15, 30, 60].map(d => <option key={d} value={d}>{d}s</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Resolution</label>
                  <select value={resolution} onChange={e => setResolution(e.target.value)}>
                    <option>720p</option><option>1080p</option><option>1440p</option><option>4K</option>
                  </select>
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={generating || !prompt.trim()}
              className="btn btn-primary w-full"
            >
              {generating ? (
                <><FiLoader className="animate-spin" size={16} /> Generating...</>
              ) : (
                <><FiZap size={16} /> Generate Video</>
              )}
            </button>
          </div>
        </div>

        {/* Generation history */}
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2"><FiClock size={18} className="text-primary" /> Generation History</h2>
              <span className="badge bg-[var(--bg-tertiary)]">{generations.length} items</span>
            </div>

            {generations.length === 0 ? (
              <div className="text-center py-12 text-[var(--text-muted)]">
                <FiVideo size={48} className="mx-auto mb-4 opacity-30" />
                <p>No generations yet. Start by entering a prompt.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                {generations.map((gen) => (
                  <div key={gen.id} className="p-4 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-color)]">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{gen.prompt.slice(0, 100)}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-[var(--text-muted)]">
                          <span className="flex items-center gap-1"><FiVideo size={12} /> {gen.generation_type}</span>
                          <span>{gen.resolution}</span>
                          <span>{gen.duration}s</span>
                          <span>{formatDate(gen.created_at)}</span>
                        </div>
                      </div>
                      <span className={`badge flex-shrink-0 ${statusColor(gen.status)}`}>
                        {gen.status === 'completed' && <FiCheckCircle size={12} />}
                        {gen.status === 'processing' && <FiLoader size={12} className="animate-spin" />}
                        {gen.status === 'failed' && <FiAlertCircle size={12} />}
                        <span className="ml-1">{gen.status}</span>
                      </span>
                    </div>
                    {gen.enhanced_prompt && (
                      <p className="text-xs text-[var(--text-muted)] bg-[var(--bg-primary)] rounded p-2 mb-2">{gen.enhanced_prompt.slice(0, 150)}...</p>
                    )}
                    {gen.error_message && (
                      <p className="text-xs text-red-400 bg-red-500/10 rounded p-2 mb-2">{gen.error_message}</p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      {gen.output_url && (
                        <a href={gen.output_url} target="_blank" className="btn btn-secondary btn-sm">
                          <FiDownload size={12} /> Download
                        </a>
                      )}
                      <button onClick={() => navigator.clipboard.writeText(gen.prompt)} className="btn btn-ghost btn-sm text-xs">Copy Prompt</button>
                      <div className="flex-1" />
                      <button onClick={() => handleDelete(gen.id)} className="btn btn-ghost btn-sm text-red-400 hover:bg-red-500/10">
                        <FiTrash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}