'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { api } from '@/lib/api';
import {
  FiFolder, FiPlus, FiTrash2, FiEdit3, FiPlay,
  FiCalendar, FiFilm, FiFileText, FiMic, FiImage,
} from 'react-icons/fi';
import { formatDate, statusColor } from '@/lib/utils';
import type { Project } from '@/types';

export default function ProjectsPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [projType, setProjType] = useState('text-to-video');

  useEffect(() => {
    if (!isLoading && !user) { router.push('/login'); return; }
    if (user) loadProjects();
  }, [user, isLoading, router]);

  const loadProjects = async () => {
    try { const r = await api.listProjects(1, 50); setProjects(r.items); } catch {}
  };

  const resetForm = () => { setTitle(''); setDesc(''); setProjType('text-to-video'); setEditingId(null); };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      if (editingId) {
        await api.updateProject(editingId, { title, description: desc, project_type: projType });
      } else {
        await api.createProject({ title, description: desc, project_type: projType });
      }
      setShowForm(false); resetForm();
      await loadProjects();
    } catch {}
  };

  const handleDelete = async (id: string) => {
    try { await api.deleteProject(id); setProjects(prev => prev.filter(p => p.id !== id)); } catch {}
  };

  const typeIcons: Record<string, React.ElementType> = {
    'text-to-video': FiFileText,
    'image-to-video': FiImage,
    'video-to-video': FiFilm,
  };

  if (isLoading || !user) {
    return <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)]"><FiFolder className="animate-pulse text-primary" size={32} /></div>;
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold">Projects</h1>
          <p className="text-[var(--text-secondary)]">Manage your video projects.</p>
        </div>
        <button onClick={() => { resetForm(); setShowForm(!showForm); }} className="btn btn-primary">
          <FiPlus size={16} /> {showForm ? 'Cancel' : 'New Project'}
        </button>
      </div>

      {showForm && (
        <div className="card mb-6 animate-slide-down">
          <h2 className="font-semibold mb-4">{editingId ? 'Edit Project' : 'Create Project'}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Title</label>
                <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Project title" required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Project Type</label>
                <select value={projType} onChange={e => setProjType(e.target.value)}>
                  <option value="text-to-video">Text to Video</option>
                  <option value="image-to-video">Image to Video</option>
                  <option value="video-to-video">Video to Video</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Description</label>
              <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} placeholder="Project description..." />
            </div>
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => { setShowForm(false); resetForm(); }} className="btn btn-secondary">Cancel</button>
              <button type="submit" className="btn btn-primary">{editingId ? 'Update' : 'Create'} Project</button>
            </div>
          </form>
        </div>
      )}

      {projects.length === 0 ? (
        <div className="text-center py-16 text-[var(--text-muted)]">
          <FiFolder size={56} className="mx-auto mb-4 opacity-30" />
          <p className="text-lg mb-4">No projects yet.</p>
          <button onClick={() => setShowForm(true)} className="btn btn-primary"><FiPlus size={16} /> Create Your First Project</button>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.map(p => {
            const TypeIcon = typeIcons[p.project_type] || FiFolder;
            return (
              <div key={p.id} className="card group cursor-pointer hover:border-primary/50 transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-[var(--bg-tertiary)] flex items-center justify-center border border-[var(--border-color)]">
                      <TypeIcon size={22} className="text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{p.title}</h3>
                      <span className="text-xs text-[var(--text-muted)]">{p.project_type}</span>
                    </div>
                  </div>
                  <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => { setEditingId(p.id); setTitle(p.title); setDesc(p.description || ''); setProjType(p.project_type); setShowForm(true); }} className="p-1.5 rounded hover:bg-[var(--bg-tertiary)]">
                      <FiEdit3 size={14} className="text-[var(--text-muted)]" />
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="p-1.5 rounded hover:bg-red-500/10">
                      <FiTrash2 size={14} className="text-red-400" />
                    </button>
                  </div>
                </div>
                {p.description && <p className="text-sm text-[var(--text-secondary)] line-clamp-2 mb-3">{p.description}</p>}
                <div className="flex items-center justify-between">
                  <span className={`badge ${statusColor(p.status)}`}>{p.status}</span>
                  <span className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                    <FiCalendar size={12} /> {formatDate(p.updated_at)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}