'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { FiZap, FiMail, FiAlertCircle, FiCheckCircle } from 'react-icons/fi';
import { api } from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [step, setStep] = useState<'request' | 'reset'>('request');

  const handleRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api.requestPasswordReset(email);
      if (res.token) { setResetToken(res.token); setStep('reset'); }
      setSuccess(true);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Request failed');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await api.confirmPasswordReset(resetToken, newPassword);
      alert('Password reset successful! You can now login.');
      window.location.href = '/login';
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Reset failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--bg-primary)] px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-4">
            <FiZap className="text-white" size={24} />
          </div>
          <h1 className="text-2xl font-bold">Reset Password</h1>
        </div>

        <div className="card">
          {step === 'request' ? (
            <form onSubmit={handleRequest} className="space-y-4">
              {error && <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm"><FiAlertCircle size={16} /> {error}</div>}
              {success && <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400 text-sm"><FiCheckCircle size={16} /> Reset email sent (check token in response)</div>}
              <div>
                <label className="block text-sm font-medium mb-1.5">Email</label>
                <div className="relative">
                  <FiMail className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={16} />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="pl-10" required />
                </div>
              </div>
              <button type="submit" disabled={loading} className="btn btn-primary w-full">{loading ? 'Sending...' : 'Send Reset Link'}</button>
            </form>
          ) : (
            <form onSubmit={handleReset} className="space-y-4">
              {error && <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm"><FiAlertCircle size={16} /> {error}</div>}
              <div>
                <label className="block text-sm font-medium mb-1.5">Reset Token</label>
                <input type="text" value={resetToken} onChange={e => setResetToken(e.target.value)} placeholder="Enter token" required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">New Password</label>
                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Min. 8 characters" required />
              </div>
              <button type="submit" disabled={loading} className="btn btn-primary w-full">{loading ? 'Resetting...' : 'Reset Password'}</button>
              <button type="button" onClick={() => setStep('request')} className="btn btn-ghost w-full text-sm">Back</button>
            </form>
          )}
          <div className="mt-4 text-center text-sm text-[var(--text-secondary)]">
            <Link href="/login" className="text-primary hover:underline">Back to Sign In</Link>
          </div>
        </div>
      </div>
    </div>
  );
}