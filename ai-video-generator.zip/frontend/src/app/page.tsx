'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import Link from 'next/link';
import { FiZap, FiVideo, FiEdit3, FiUsers, FiArrowRight, FiPlay } from 'react-icons/fi';

export default function Home() {
  const { isAuthenticated } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (isAuthenticated) router.push('/dashboard');
  }, [isAuthenticated, router]);

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 h-16 border-b border-[var(--border-color)]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <FiZap className="text-white" size={18} />
          </div>
          <span className="font-bold text-xl">
            <span className="gradient-text">AI Video</span>
            <span className="text-[var(--text-primary)]">Gen</span>
          </span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/login" className="btn btn-ghost btn-sm">Sign In</Link>
          <Link href="/signup" className="btn btn-primary btn-sm">Get Started</Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-5xl mx-auto px-6 pt-24 pb-16 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm mb-8">
          <FiPlay size={14} /> Now with AI-powered video generation
        </div>
        <h1 className="text-5xl md:text-7xl font-extrabold leading-tight mb-6">
          Create Stunning Videos{' '}
          <span className="gradient-text">with AI</span>
        </h1>
        <p className="text-xl text-[var(--text-secondary)] mb-10 max-w-2xl mx-auto leading-relaxed">
          Transform text, images, and videos into professional content using cutting-edge artificial intelligence. Script writing, character creation, voice synthesis, and full video editing — all in one platform.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Link href="/signup" className="btn btn-primary btn-lg">
            Start Creating Free <FiArrowRight size={20} />
          </Link>
          <Link href="/login" className="btn btn-secondary btn-lg">
            Sign In
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: FiVideo, title: 'Text to Video', desc: 'Generate videos from text prompts with AI' },
            { icon: FiEdit3, title: 'Prompt Studio', desc: 'Enhance and generate professional prompts' },
            { icon: FiUsers, title: 'Characters', desc: 'Create consistent AI characters' },
            { icon: FiZap, title: 'Voice AI', desc: 'Generate and clone voice narration' },
          ].map((f, i) => {
            const Icon = f.icon;
            return (
              <div key={i} className="card text-center group">
                <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/25 transition-colors">
                  <Icon className="text-primary" size={24} />
                </div>
                <h3 className="font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-[var(--text-secondary)]">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[var(--border-color)] py-8 px-6 text-center text-sm text-[var(--text-muted)]">
        <p>&copy; 2024 AI Video Generator. All rights reserved.</p>
      </footer>
    </div>
  );
}