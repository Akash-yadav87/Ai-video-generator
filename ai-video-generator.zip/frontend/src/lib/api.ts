const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

type RequestOptions = {
  method?: string;
  body?: unknown;
  headers?: Record<string, string>;
  token?: string | null;
};

class ApiClient {
  private getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('access_token');
  }

  private async request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    const { method = 'GET', body, headers = {}, token } = options;
    const authToken = token || this.getToken();

    const config: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
        ...headers,
      },
    };

    if (body && method !== 'GET') {
      config.body = JSON.stringify(body);
    }

    const res = await fetch(`${API_BASE}${endpoint}`, config);

    if (!res.ok) {
      const error = await res.json().catch(() => ({ detail: 'Request failed' }));
      throw new Error(error.detail || `HTTP ${res.status}`);
    }

    return res.json();
  }

  // Auth
  async login(email: string, password: string) {
    return this.request<{ access_token: string; refresh_token: string; token_type: string }>('/auth/login', {
      method: 'POST', body: { email, password },
    });
  }

  async signup(email: string, username: string, password: string, full_name?: string) {
    return this.request<{ access_token: string; refresh_token: string }>('/auth/signup', {
      method: 'POST', body: { email, username, password, full_name },
    });
  }

  async getMe() {
    return this.request<import('@/types').User>('/auth/me');
  }

  async refreshToken(refreshToken: string) {
    return this.request<{ access_token: string; refresh_token: string }>('/auth/refresh', {
      method: 'POST', body: { refresh_token: refreshToken },
    });
  }

  async requestPasswordReset(email: string) {
    return this.request<{ message: string; token?: string }>('/auth/password-reset-request', {
      method: 'POST', body: { email },
    });
  }

  async confirmPasswordReset(token: string, new_password: string) {
    return this.request<{ message: string }>('/auth/password-reset-confirm', {
      method: 'POST', body: { token, new_password },
    });
  }

  async changePassword(current_password: string, new_password: string) {
    return this.request<{ message: string }>('/auth/change-password', {
      method: 'POST', body: { current_password, new_password },
    });
  }

  // Video
  async generateVideo(data: {
    generation_type: string; prompt: string; negative_prompt?: string;
    source_url?: string; duration?: number; resolution?: string; project_id?: string;
  }) {
    return this.request<import('@/types').VideoGeneration>('/video/generate', { method: 'POST', body: data });
  }

  async listGenerations(page = 1, page_size = 20, generation_type?: string) {
    const params = new URLSearchParams({ page: String(page), page_size: String(page_size) });
    if (generation_type) params.set('generation_type', generation_type);
    return this.request<import('@/types').PaginatedResponse<import('@/types').VideoGeneration>>(`/video/generations?${params}`);
  }

  async getGeneration(id: string) {
    return this.request<import('@/types').VideoGeneration>(`/video/generations/${id}`);
  }

  async deleteGeneration(id: string) {
    return this.request<{ message: string }>(`/video/generations/${id}`, { method: 'DELETE' });
  }

  // Prompts
  async enhancePrompt(raw_prompt: string, style = 'cinematic', tone = 'professional') {
    return this.request<{ raw_prompt: string; enhanced_prompt: string }>('/prompts/enhance', {
      method: 'POST', body: { raw_prompt, style, tone },
    });
  }

  async generatePrompt(topic: string, style = 'cinematic', tone = 'dramatic', length = 'medium') {
    return this.request<{ topic: string; style: string; tone: string; variants: { index: number; prompt: string; enhanced: string }[] }>('/prompts/generate', {
      method: 'POST', body: { topic, style, tone, length },
    });
  }

  async savePrompt(data: { title?: string; raw_prompt: string; enhanced_prompt?: string; category?: string; tags?: string[] }) {
    return this.request<import('@/types').SavedPrompt>('/prompts', { method: 'POST', body: data });
  }

  async listPrompts(page = 1, page_size = 20) {
    const params = new URLSearchParams({ page: String(page), page_size: String(page_size) });
    return this.request<import('@/types').PaginatedResponse<import('@/types').SavedPrompt>>(`/prompts?${params}`);
  }

  async toggleFavorite(promptId: string) {
    return this.request<{ is_favorite: boolean }>(`/prompts/${promptId}/favorite`, { method: 'POST' });
  }

  // Scripts
  async generateScript(data: { title: string; genre: string; premise: string; num_scenes: number; include_dialogue: boolean; character_names?: string[] }) {
    return this.request<import('@/types').Script>('/scripts/generate', { method: 'POST', body: data });
  }

  async listScripts(page = 1, page_size = 20) {
    const params = new URLSearchParams({ page: String(page), page_size: String(page_size) });
    return this.request<import('@/types').PaginatedResponse<import('@/types').Script>>(`/scripts?${params}`);
  }

  async getScript(id: string) {
    return this.request<import('@/types').Script>(`/scripts/${id}`);
  }

  // Characters
  async createCharacter(data: { name: string; description?: string; appearance?: string; personality?: string; reference_images?: string[]; voice_id?: string }) {
    return this.request<import('@/types').Character>('/characters', { method: 'POST', body: data });
  }

  async listCharacters(page = 1, page_size = 20) {
    const params = new URLSearchParams({ page: String(page), page_size: String(page_size) });
    return this.request<import('@/types').PaginatedResponse<import('@/types').Character>>(`/characters?${params}`);
  }

  async updateCharacter(id: string, data: Record<string, unknown>) {
    return this.request<import('@/types').Character>(`/characters/${id}`, { method: 'PUT', body: data });
  }

  async deleteCharacter(id: string) {
    return this.request<{ message: string }>(`/characters/${id}`, { method: 'DELETE' });
  }

  // Voice
  async generateVoice(text: string, voice_id?: string, provider = 'elevenlabs', speed = 1.0, pitch = 1.0) {
    return this.request<{ audio_url: string; duration_seconds: number }>('/voice/generate', {
      method: 'POST', body: { text, voice_id, provider, speed, pitch },
    });
  }

  async listVoiceProfiles() {
    return this.request<import('@/types').VoiceProfile[]>('/voice/profiles');
  }

  // Projects
  async createProject(data: { title: string; description?: string; project_type?: string }) {
    return this.request<import('@/types').Project>('/projects', { method: 'POST', body: data });
  }

  async listProjects(page = 1, page_size = 20, status?: string) {
    const params = new URLSearchParams({ page: String(page), page_size: String(page_size) });
    if (status) params.set('status', status);
    return this.request<import('@/types').PaginatedResponse<import('@/types').Project>>(`/projects?${params}`);
  }

  async getProject(id: string) {
    return this.request<import('@/types').Project>(`/projects/${id}`);
  }

  async updateProject(id: string, data: Record<string, unknown>) {
    return this.request<import('@/types').Project>(`/projects/${id}`, { method: 'PUT', body: data });
  }

  async deleteProject(id: string) {
    return this.request<{ message: string }>(`/projects/${id}`, { method: 'DELETE' });
  }

  // Editor
  async getEditorData(projectId: string) {
    return this.request<import('@/types').EditorData>(`/editor/${projectId}`);
  }

  async saveEditorData(projectId: string, data: Record<string, unknown>) {
    return this.request<import('@/types').EditorData>(`/editor/${projectId}`, { method: 'PUT', body: data });
  }

  // Settings
  async getSettings() {
    return this.request<import('@/types').UserSettings>('/settings');
  }

  async updateTheme(theme: string) {
    return this.request<{ theme: string }>('/settings/theme?theme=' + theme, { method: 'PUT' });
  }

  async updateApiKeys(api_keys: Record<string, unknown>) {
    return this.request<{ api_keys: Record<string, unknown> }>('/settings/api-keys', {
      method: 'PUT', body: { api_keys },
    });
  }

  // Admin
  async listUsers(page = 1, page_size = 20) {
    const params = new URLSearchParams({ page: String(page), page_size: String(page_size) });
    return this.request<{ items: import('@/types').User[]; total: number }>(`/admin/users?${params}`);
  }

  async updateUserRole(user_id: string, role: string) {
    return this.request<{ message: string }>(`/admin/users/${user_id}/role?role=${role}`, { method: 'PUT' });
  }

  async getAdminStats() {
    return this.request<{ total_users: number; total_projects: number; total_generations: number; total_prompts: number }>('/admin/stats');
  }
}

export const api = new ApiClient();