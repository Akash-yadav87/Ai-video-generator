export interface User {
  id: string;
  email: string;
  username: string;
  full_name: string | null;
  role: 'user' | 'admin' | 'creator';
  is_active: boolean;
  avatar_url: string | null;
  created_at: string;
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  project_type: string;
  status: string;
  thumbnail_url: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface VideoGeneration {
  id: string;
  generation_type: string;
  prompt: string;
  enhanced_prompt: string | null;
  source_url: string | null;
  output_url: string | null;
  status: string;
  duration: number;
  resolution: string;
  metadata: Record<string, unknown>;
  error_message: string | null;
  created_at: string;
  completed_at: string | null;
}

export interface SavedPrompt {
  id: string;
  title: string | null;
  raw_prompt: string;
  enhanced_prompt: string | null;
  category: string | null;
  tags: string[] | null;
  is_favorite: boolean;
  usage_count: number;
  created_at: string;
}

export interface Character {
  id: string;
  name: string;
  description: string | null;
  appearance: string | null;
  personality: string | null;
  avatar_url: string | null;
  reference_images: string[] | null;
  voice_id: string | null;
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

export interface Script {
  id: string;
  title: string;
  genre: string | null;
  logline: string | null;
  content: ScriptContent;
  created_at: string;
  updated_at: string;
}

export interface ScriptContent {
  title?: string;
  genre?: string;
  premise?: string;
  num_scenes?: number;
  scenes?: Scene[];
}

export interface Scene {
  scene_number: number;
  location: string;
  time: string;
  mood: string;
  description: string;
  dialogue: DialogueLine[];
}

export interface DialogueLine {
  character: string;
  line: string;
  direction: string;
}

export interface VoiceProfile {
  id: string;
  name: string;
  voice_id: string | null;
  provider: string;
  sample_url: string | null;
  settings: Record<string, unknown>;
  is_public: boolean;
  created_at: string;
}

export interface EditorData {
  id: string;
  project_id: string;
  timeline: TimelineData;
  effects: Effect[];
  transitions: Transition[];
  subtitles: Subtitle[];
}

export interface TimelineData {
  tracks: Track[];
  duration: number;
}

export interface Track {
  id: string;
  name: string;
  clips: Clip[];
}

export interface Clip {
  id: string;
  start: number;
  end: number;
  source: string;
  type: 'video' | 'audio' | 'image' | 'text';
}

export interface Effect {
  id: string;
  type: string;
  params: Record<string, unknown>;
  start: number;
  end: number;
}

export interface Transition {
  id: string;
  type: string;
  duration: number;
  at: number;
}

export interface Subtitle {
  id: string;
  text: string;
  start: number;
  end: number;
  style?: Record<string, unknown>;
}

export interface UserSettings {
  theme: string;
  language: string;
  notification_prefs: Record<string, unknown>;
  api_keys: Record<string, unknown>;
  generation_limits: Record<string, unknown>;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}
