'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  FiHome, FiVideo, FiEdit3, FiFileText, FiUsers,
  FiMic, FiFilm, FiFolder, FiSettings, FiChevronLeft,
  FiChevronRight, FiZap, FiLogOut,
} from 'react-icons/fi';
import { useAuth } from '@/contexts/AuthContext';

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: FiHome },
  { href: '/video-generator', label: 'Video Generator', icon: FiVideo },
  { href: '/prompt-studio', label: 'Prompt Studio', icon: FiEdit3 },
  { href: '/script-writer', label: 'AI Script Writer', icon: FiFileText },
  { href: '/characters', label: 'Characters', icon: FiUsers },
  { href: '/voice-ai', label: 'Voice AI', icon: FiMic },
  { href: '/video-editor', label: 'Video Editor', icon: FiFilm },
  { href: '/projects', label: 'Projects', icon: FiFolder },
  { href: '/settings', label: 'Settings', icon: FiSettings },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuth();

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 h-full z-40 flex flex-col border-r transition-all duration-300',
        'bg-[var(--bg-secondary)] border-[var(--border-color)]',
        collapsed ? 'w-[70px]' : 'w-[260px]',
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-[var(--border-color)]">
        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
          <FiZap className="text-white" size={18} />
        </div>
        {!collapsed && (
          <span className="font-bold text-lg tracking-tight">
            <span className="gradient-text">AI Video</span>
          </span>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group',
                isActive
                  ? 'bg-primary/15 text-primary border border-primary/30'
                  : 'text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] hover:text-[var(--text-primary)]',
              )}
            >
              <Icon size={20} className="flex-shrink-0" />
              {!collapsed && <span className="text-sm font-medium">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* User & collapse */}
      <div className="border-t border-[var(--border-color)] p-3 space-y-2">
        {!collapsed && user && (
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm font-bold">
              {user.username[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.username}</p>
              <p className="text-xs text-[var(--text-muted)] truncate">{user.email}</p>
            </div>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] transition-colors"
        >
          {collapsed ? <FiChevronRight size={16} /> : <FiChevronLeft size={16} />}
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  );
}