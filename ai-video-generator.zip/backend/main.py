from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from app.core.database import init_db
from app.routes import auth, video, prompts, scripts, characters, voice, projects, editor, settings, admin


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    os.makedirs("uploads/videos", exist_ok=True)
    os.makedirs("uploads/voice", exist_ok=True)
    os.makedirs("uploads/images", exist_ok=True)
    yield


app = FastAPI(
    title="AI Video Generator API",
    version="1.0.0",
    description="AI-powered video generation platform",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routes
app.include_router(auth.router, prefix="/api/v1")
app.include_router(video.router, prefix="/api/v1")
app.include_router(prompts.router, prefix="/api/v1")
app.include_router(scripts.router, prefix="/api/v1")
app.include_router(characters.router, prefix="/api/v1")
app.include_router(voice.router, prefix="/api/v1")
app.include_router(projects.router, prefix="/api/v1")
app.include_router(editor.router, prefix="/api/v1")
app.include_router(settings.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")

# Static files for uploads
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


@app.get("/")
async def root():
    return {"message": "AI Video Generator API", "version": "1.0.0", "docs": "/docs"}


@app.get("/health")
async def health():
    return {"status": "healthy"}
