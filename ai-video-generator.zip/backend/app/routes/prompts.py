from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, Prompt
from app.schemas.prompt import PromptEnhanceRequest, PromptGenerateRequest, PromptSaveRequest, PromptResponse, PromptList
from app.services.ai_service import enhance_prompt, generate_prompt

router = APIRouter(prefix="/prompts", tags=["prompts"])


@router.post("/enhance")
async def enhance(data: PromptEnhanceRequest, current_user: User = Depends(get_current_user)):
    enhanced = await enhance_prompt(data.raw_prompt, style=data.style, tone=data.tone)
    return {"raw_prompt": data.raw_prompt, "enhanced_prompt": enhanced, "style": data.style, "tone": data.tone}


@router.post("/generate")
async def generate(data: PromptGenerateRequest, current_user: User = Depends(get_current_user)):
    result = await generate_prompt(data.topic, style=data.style, tone=data.tone, length=data.length)
    return result


@router.post("", response_model=PromptResponse, status_code=status.HTTP_201_CREATED)
async def save_prompt(data: PromptSaveRequest, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    prompt = Prompt(
        user_id=current_user.id,
        title=data.title,
        raw_prompt=data.raw_prompt,
        enhanced_prompt=data.enhanced_prompt,
        category=data.category,
        tags=data.tags,
    )
    db.add(prompt)
    await db.commit()
    await db.refresh(prompt)
    return PromptResponse(
        id=str(prompt.id), title=prompt.title, raw_prompt=prompt.raw_prompt,
        enhanced_prompt=prompt.enhanced_prompt, category=prompt.category,
        tags=prompt.tags, is_favorite=prompt.is_favorite, usage_count=prompt.usage_count,
        created_at=prompt.created_at.isoformat() if prompt.created_at else "",
    )


@router.get("", response_model=PromptList)
async def list_prompts(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    category: str | None = None, favorite: bool | None = None,
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    query = select(Prompt).where(Prompt.user_id == current_user.id)
    count_q = select(func.count(Prompt.id)).where(Prompt.user_id == current_user.id)
    if category:
        query = query.where(Prompt.category == category)
        count_q = count_q.where(Prompt.category == category)
    if favorite:
        query = query.where(Prompt.is_favorite == True)
        count_q = count_q.where(Prompt.is_favorite == True)

    total = (await db.execute(count_q)).scalar()
    result = await db.execute(query.order_by(Prompt.created_at.desc()).limit(page_size).offset((page - 1) * page_size))
    items = result.scalars().all()

    return PromptList(
        items=[PromptResponse(
            id=str(p.id), title=p.title, raw_prompt=p.raw_prompt, enhanced_prompt=p.enhanced_prompt,
            category=p.category, tags=p.tags, is_favorite=p.is_favorite, usage_count=p.usage_count,
            created_at=p.created_at.isoformat() if p.created_at else "",
        ) for p in items],
        total=total, page=page, page_size=page_size,
    )


@router.get("/{prompt_id}", response_model=PromptResponse)
async def get_prompt(prompt_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Prompt).where(Prompt.id == prompt_id, Prompt.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prompt not found")
    return PromptResponse(
        id=str(p.id), title=p.title, raw_prompt=p.raw_prompt, enhanced_prompt=p.enhanced_prompt,
        category=p.category, tags=p.tags, is_favorite=p.is_favorite, usage_count=p.usage_count,
        created_at=p.created_at.isoformat() if p.created_at else "",
    )


@router.delete("/{prompt_id}")
async def delete_prompt(prompt_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Prompt).where(Prompt.id == prompt_id, Prompt.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prompt not found")
    await db.delete(p)
    await db.commit()
    return {"message": "Prompt deleted"}


@router.post("/{prompt_id}/favorite")
async def toggle_favorite(prompt_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Prompt).where(Prompt.id == prompt_id, Prompt.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prompt not found")
    p.is_favorite = not p.is_favorite
    await db.commit()
    return {"is_favorite": p.is_favorite}
