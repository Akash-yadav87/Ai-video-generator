from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, UserSettings

router = APIRouter(prefix="/settings", tags=["settings"])


@router.get("")
async def get_settings(current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    s = current_user.settings
    if not s:
        s = UserSettings(user_id=current_user.id)
        db.add(s)
        await db.commit()
        await db.refresh(s)
    return {
        "theme": s.theme, "language": s.language,
        "notification_prefs": s.notification_prefs or {},
        "api_keys": s.api_keys or {}, "generation_limits": s.generation_limits or {},
    }


@router.put("/theme")
async def update_theme(theme: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    s = current_user.settings
    if not s:
        s = UserSettings(user_id=current_user.id)
        db.add(s)
    s.theme = theme
    await db.commit()
    return {"theme": s.theme}


@router.put("/api-keys")
async def update_api_keys(api_keys: dict, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    s = current_user.settings
    if not s:
        s = UserSettings(user_id=current_user.id)
        db.add(s)
    s.api_keys = {**s.api_keys, **api_keys} if s.api_keys else api_keys
    await db.commit()
    return {"api_keys": s.api_keys}


@router.put("/notifications")
async def update_notifications(prefs: dict, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    s = current_user.settings
    if not s:
        s = UserSettings(user_id=current_user.id)
        db.add(s)
    s.notification_prefs = {**s.notification_prefs, **prefs} if s.notification_prefs else prefs
    await db.commit()
    return {"notification_prefs": s.notification_prefs}
