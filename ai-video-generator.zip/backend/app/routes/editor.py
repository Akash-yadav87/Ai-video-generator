from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, Project, EditorData

router = APIRouter(prefix="/editor", tags=["editor"])


@router.get("/{project_id}")
async def get_editor_data(project_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Project).where(Project.id == project_id, Project.user_id == current_user.id))
    project = res.scalar_one_or_none()
    if not project: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

    res2 = await db.execute(select(EditorData).where(EditorData.project_id == project_id))
    data = res2.scalar_one_or_none()
    if not data:
        data = EditorData(project_id=project_id, timeline={"tracks": [], "duration": 0})
        db.add(data)
        await db.commit()
        await db.refresh(data)

    return {
        "id": str(data.id), "project_id": str(data.project_id),
        "timeline": data.timeline or {}, "effects": data.effects or [],
        "transitions": data.transitions or [], "subtitles": data.subtitles or [],
    }


@router.put("/{project_id}")
async def save_editor_data(
    project_id: str,
    timeline: dict | None = None,
    effects: list | None = None,
    transitions: list | None = None,
    subtitles: list | None = None,
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    res = await db.execute(select(Project).where(Project.id == project_id, Project.user_id == current_user.id))
    project = res.scalar_one_or_none()
    if not project: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

    res2 = await db.execute(select(EditorData).where(EditorData.project_id == project_id))
    data = res2.scalar_one_or_none()
    if not data:
        data = EditorData(project_id=project_id)
        db.add(data)

    if timeline is not None: data.timeline = timeline
    if effects is not None: data.effects = effects
    if transitions is not None: data.transitions = transitions
    if subtitles is not None: data.subtitles = subtitles

    await db.commit()
    await db.refresh(data)
    return {
        "id": str(data.id), "project_id": str(data.project_id),
        "timeline": data.timeline or {}, "effects": data.effects or [],
        "transitions": data.transitions or [], "subtitles": data.subtitles or [],
    }
