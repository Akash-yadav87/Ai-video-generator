from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, Character
from app.schemas.character import CharacterCreate, CharacterUpdate, CharacterResponse, CharacterList

router = APIRouter(prefix="/characters", tags=["characters"])


@router.post("", response_model=CharacterResponse, status_code=status.HTTP_201_CREATED)
async def create_character(data: CharacterCreate, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    character = Character(user_id=current_user.id, **data.model_dump())
    db.add(character)
    await db.commit()
    await db.refresh(character)
    return _to_response(character)


@router.get("", response_model=CharacterList)
async def list_characters(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    query = select(Character).where(Character.user_id == current_user.id)
    count_q = select(func.count(Character.id)).where(Character.user_id == current_user.id)
    total = (await db.execute(count_q)).scalar()
    result = await db.execute(query.order_by(Character.created_at.desc()).limit(page_size).offset((page - 1) * page_size))
    return CharacterList(items=[_to_response(c) for c in result.scalars().all()], total=total, page=page, page_size=page_size)


@router.get("/{character_id}", response_model=CharacterResponse)
async def get_character(character_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Character).where(Character.id == character_id, Character.user_id == current_user.id))
    c = result.scalar_one_or_none()
    if not c: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Character not found")
    return _to_response(c)


@router.put("/{character_id}", response_model=CharacterResponse)
async def update_character(character_id: str, data: CharacterUpdate, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Character).where(Character.id == character_id, Character.user_id == current_user.id))
    c = result.scalar_one_or_none()
    if not c: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Character not found")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(c, k, v)
    await db.commit()
    await db.refresh(c)
    return _to_response(c)


@router.delete("/{character_id}")
async def delete_character(character_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Character).where(Character.id == character_id, Character.user_id == current_user.id))
    c = result.scalar_one_or_none()
    if not c: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Character not found")
    await db.delete(c)
    await db.commit()
    return {"message": "Character deleted"}


def _to_response(c: Character) -> CharacterResponse:
    return CharacterResponse(
        id=str(c.id), name=c.name, description=c.description,
        appearance=c.appearance, personality=c.personality, avatar_url=c.avatar_url,
        reference_images=c.reference_images, voice_id=c.voice_id, is_public=c.is_public,
        created_at=c.created_at.isoformat() if c.created_at else "",
        updated_at=c.updated_at.isoformat() if c.updated_at else "",
    )
