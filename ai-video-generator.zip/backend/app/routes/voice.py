from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, VoiceProfile
from app.schemas.voice import VoiceGenerateRequest, VoiceProfileCreate, VoiceProfileResponse
from app.services.ai_service import generate_voice, get_voice_preview

router = APIRouter(prefix="/voice", tags=["voice"])


@router.post("/generate")
async def generate(data: VoiceGenerateRequest, current_user: User = Depends(get_current_user)):
    result = await generate_voice(text=data.text, voice_id=data.voice_id, provider=data.provider, speed=data.speed, pitch=data.pitch)
    return result


@router.post("/profiles", response_model=VoiceProfileResponse, status_code=status.HTTP_201_CREATED)
async def create_profile(data: VoiceProfileCreate, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    profile = VoiceProfile(user_id=current_user.id, **data.model_dump())
    db.add(profile)
    await db.commit()
    await db.refresh(profile)
    return _to_response(profile)


@router.get("/profiles")
async def list_profiles(current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(VoiceProfile).where(VoiceProfile.user_id == current_user.id))
    return [_to_response(p) for p in result.scalars().all()]


@router.get("/profiles/{profile_id}", response_model=VoiceProfileResponse)
async def get_profile(profile_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(VoiceProfile).where(VoiceProfile.id == profile_id, VoiceProfile.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")
    return _to_response(p)


@router.delete("/profiles/{profile_id}")
async def delete_profile(profile_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(VoiceProfile).where(VoiceProfile.id == profile_id, VoiceProfile.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")
    await db.delete(p)
    await db.commit()
    return {"message": "Profile deleted"}


def _to_response(p: VoiceProfile) -> VoiceProfileResponse:
    return VoiceProfileResponse(
        id=str(p.id), name=p.name, voice_id=p.voice_id, provider=p.provider,
        sample_url=p.sample_url, settings=p.settings or {}, is_public=p.is_public,
        created_at=p.created_at.isoformat() if p.created_at else "",
    )
