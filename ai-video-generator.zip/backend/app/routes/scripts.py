from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, Script
from app.schemas.script import ScriptGenerateRequest, ScriptResponse, ScriptList
from app.services.ai_service import generate_script

router = APIRouter(prefix="/scripts", tags=["scripts"])


@router.post("/generate", response_model=ScriptResponse, status_code=status.HTTP_201_CREATED)
async def generate(data: ScriptGenerateRequest, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    content = await generate_script(
        premise=data.premise, genre=data.genre, num_scenes=data.num_scenes,
        include_dialogue=data.include_dialogue, character_names=data.character_names,
    )
    script = Script(
        user_id=current_user.id,
        title=data.title,
        genre=data.genre,
        logline=data.premise[:200],
        content=content,
    )
    db.add(script)
    await db.commit()
    await db.refresh(script)
    return ScriptResponse(
        id=str(script.id), title=script.title, genre=script.genre,
        logline=script.logline, content=script.content or {},
        created_at=script.created_at.isoformat() if script.created_at else "",
        updated_at=script.updated_at.isoformat() if script.updated_at else "",
    )


@router.get("", response_model=ScriptList)
async def list_scripts(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    query = select(Script).where(Script.user_id == current_user.id)
    count_q = select(func.count(Script.id)).where(Script.user_id == current_user.id)
    total = (await db.execute(count_q)).scalar()
    result = await db.execute(query.order_by(Script.created_at.desc()).limit(page_size).offset((page - 1) * page_size))
    items = result.scalars().all()
    return ScriptList(
        items=[ScriptResponse(
            id=str(s.id), title=s.title, genre=s.genre, logline=s.logline,
            content=s.content or {}, created_at=s.created_at.isoformat() if s.created_at else "",
            updated_at=s.updated_at.isoformat() if s.updated_at else "",
        ) for s in items],
        total=total, page=page, page_size=page_size,
    )


@router.get("/{script_id}", response_model=ScriptResponse)
async def get_script(script_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Script).where(Script.id == script_id, Script.user_id == current_user.id))
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Script not found")
    return ScriptResponse(
        id=str(s.id), title=s.title, genre=s.genre, logline=s.logline,
        content=s.content or {}, created_at=s.created_at.isoformat() if s.created_at else "",
        updated_at=s.updated_at.isoformat() if s.updated_at else "",
    )


@router.delete("/{script_id}")
async def delete_script(script_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Script).where(Script.id == script_id, Script.user_id == current_user.id))
    s = result.scalar_one_or_none()
    if not s:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Script not found")
    await db.delete(s)
    await db.commit()
    return {"message": "Script deleted"}
