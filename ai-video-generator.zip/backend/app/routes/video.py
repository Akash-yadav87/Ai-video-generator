import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, VideoGeneration, Project
from app.schemas.video import VideoGenerationRequest, VideoGenerationResponse, VideoGenerationList
from app.services.ai_service import enhance_prompt, simulate_video_generation

router = APIRouter(prefix="/video", tags=["video"])


@router.post("/generate", response_model=VideoGenerationResponse, status_code=status.HTTP_201_CREATED)
async def generate_video(data: VideoGenerationRequest, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    if data.project_id:
        proj = await db.execute(select(Project).where(Project.id == data.project_id, Project.user_id == current_user.id))
        if not proj.scalar_one_or_none():
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

    enhanced = await enhance_prompt(data.prompt) if data.generation_type == "text-to-video" else None

    generation = VideoGeneration(
        user_id=current_user.id,
        project_id=data.project_id,
        generation_type=data.generation_type,
        prompt=data.prompt,
        enhanced_prompt=enhanced,
        source_url=data.source_url,
        duration=data.duration,
        resolution=data.resolution,
        metadata={"negative_prompt": data.negative_prompt},
    )
    db.add(generation)
    await db.commit()
    await db.refresh(generation)

    # Simulate async generation
    await simulate_video_generation(generation, db)

    await db.refresh(generation)
    return VideoGenerationResponse(
        id=str(generation.id), generation_type=generation.generation_type,
        prompt=generation.prompt, enhanced_prompt=generation.enhanced_prompt,
        source_url=generation.source_url, output_url=generation.output_url,
        status=generation.status, duration=generation.duration,
        resolution=generation.resolution, metadata=generation.metadata or {},
        error_message=generation.error_message,
        created_at=generation.created_at.isoformat() if generation.created_at else "",
        completed_at=generation.completed_at.isoformat() if generation.completed_at else None,
    )


@router.get("/generations", response_model=VideoGenerationList)
async def list_generations(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    generation_type: str | None = None,
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    query = select(VideoGeneration).where(VideoGeneration.user_id == current_user.id)
    count_query = select(func.count(VideoGeneration.id)).where(VideoGeneration.user_id == current_user.id)

    if generation_type:
        query = query.where(VideoGeneration.generation_type == generation_type)
        count_query = count_query.where(VideoGeneration.generation_type == generation_type)

    total = (await db.execute(count_query)).scalar()
    result = await db.execute(query.order_by(VideoGeneration.created_at.desc()).limit(page_size).offset((page - 1) * page_size))
    items = result.scalars().all()

    return VideoGenerationList(
        items=[VideoGenerationResponse(
            id=str(g.id), generation_type=g.generation_type, prompt=g.prompt,
            enhanced_prompt=g.enhanced_prompt, source_url=g.source_url, output_url=g.output_url,
            status=g.status, duration=g.duration, resolution=g.resolution,
            metadata=g.metadata or {}, error_message=g.error_message,
            created_at=g.created_at.isoformat() if g.created_at else "",
            completed_at=g.completed_at.isoformat() if g.completed_at else None,
        ) for g in items],
        total=total, page=page, page_size=page_size,
    )


@router.get("/generations/{generation_id}", response_model=VideoGenerationResponse)
async def get_generation(generation_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(VideoGeneration).where(VideoGeneration.id == generation_id, VideoGeneration.user_id == current_user.id)
    )
    g = result.scalar_one_or_none()
    if not g:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Generation not found")

    return VideoGenerationResponse(
        id=str(g.id), generation_type=g.generation_type, prompt=g.prompt,
        enhanced_prompt=g.enhanced_prompt, source_url=g.source_url, output_url=g.output_url,
        status=g.status, duration=g.duration, resolution=g.resolution,
        metadata=g.metadata or {}, error_message=g.error_message,
        created_at=g.created_at.isoformat() if g.created_at else "",
        completed_at=g.completed_at.isoformat() if g.completed_at else None,
    )


@router.delete("/generations/{generation_id}")
async def delete_generation(generation_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(VideoGeneration).where(VideoGeneration.id == generation_id, VideoGeneration.user_id == current_user.id)
    )
    g = result.scalar_one_or_none()
    if not g:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Generation not found")

    await db.delete(g)
    await db.commit()
    return {"message": "Generation deleted"}