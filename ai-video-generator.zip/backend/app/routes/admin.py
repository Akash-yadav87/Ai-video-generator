from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.core.deps import get_admin_user
from app.models.models import User, VideoGeneration, Project, Prompt, Character, Script

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/users")
async def list_users(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).limit(page_size).offset((page - 1) * page_size))
    total = (await db.execute(select(func.count(User.id)))).scalar()
    users = result.scalars().all()
    return {
        "total": total, "page": page, "page_size": page_size,
        "items": [{"id": str(u.id), "email": u.email, "username": u.username, "full_name": u.full_name, "role": u.role, "is_active": u.is_active, "created_at": u.created_at.isoformat() if u.created_at else ""} for u in users]
    }


@router.put("/users/{user_id}/role")
async def update_user_role(user_id: str, role: str, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    if role not in ("user", "admin", "creator"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid role")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    user.role = role
    await db.commit()
    return {"message": f"User role updated to {role}"}


@router.put("/users/{user_id}/toggle-active")
async def toggle_user_active(user_id: str, admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    user.is_active = not user.is_active
    await db.commit()
    return {"is_active": user.is_active}


@router.get("/stats")
async def get_stats(admin: User = Depends(get_admin_user), db: AsyncSession = Depends(get_db)):
    users = (await db.execute(select(func.count(User.id)))).scalar()
    projects = (await db.execute(select(func.count(Project.id)))).scalar()
    generations = (await db.execute(select(func.count(VideoGeneration.id)))).scalar()
    prompts = (await db.execute(select(func.count(Prompt.id)))).scalar()
    characters = (await db.execute(select(func.count(Character.id)))).scalar()
    scripts = (await db.execute(select(func.count(Script.id)))).scalar()
    return {
        "total_users": users, "total_projects": projects, "total_generations": generations,
        "total_prompts": prompts, "total_characters": characters, "total_scripts": scripts,
    }
