from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.models import User, Project
from app.schemas.project import ProjectCreate, ProjectUpdate, ProjectResponse, ProjectList

router = APIRouter(prefix="/projects", tags=["projects"])


@router.post("", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
async def create_project(data: ProjectCreate, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    project = Project(user_id=current_user.id, **data.model_dump())
    db.add(project)
    await db.commit()
    await db.refresh(project)
    return _to_response(project)


@router.get("", response_model=ProjectList)
async def list_projects(
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    status: str | None = None,
    current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)
):
    query = select(Project).where(Project.user_id == current_user.id)
    count_q = select(func.count(Project.id)).where(Project.user_id == current_user.id)
    if status:
        query = query.where(Project.status == status)
        count_q = count_q.where(Project.status == status)

    total = (await db.execute(count_q)).scalar()
    result = await db.execute(query.order_by(Project.updated_at.desc()).limit(page_size).offset((page - 1) * page_size))
    return ProjectList(items=[_to_response(p) for p in result.scalars().all()], total=total, page=page, page_size=page_size)


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Project).where(Project.id == project_id, Project.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    return _to_response(p)


@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(project_id: str, data: ProjectUpdate, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Project).where(Project.id == project_id, Project.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    await db.commit()
    await db.refresh(p)
    return _to_response(p)


@router.delete("/{project_id}")
async def delete_project(project_id: str, current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Project).where(Project.id == project_id, Project.user_id == current_user.id))
    p = result.scalar_one_or_none()
    if not p: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    await db.delete(p)
    await db.commit()
    return {"message": "Project deleted"}


def _to_response(p: Project) -> ProjectResponse:
    return ProjectResponse(
        id=str(p.id), user_id=str(p.user_id), title=p.title, description=p.description,
        project_type=p.project_type, status=p.status, thumbnail_url=p.thumbnail_url,
        metadata=p.metadata or {}, created_at=p.created_at.isoformat() if p.created_at else "",
        updated_at=p.updated_at.isoformat() if p.updated_at else "",
    )
