from pydantic import BaseModel, Field


class ScriptGenerateRequest(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    genre: str = "drama"
    premise: str = Field(min_length=10, max_length=5000)
    num_scenes: int = Field(default=5, ge=1, le=50)
    include_dialogue: bool = True
    character_names: list[str] | None = None


class ScriptResponse(BaseModel):
    id: str
    title: str
    genre: str | None
    logline: str | None
    content: dict = {}
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True


class ScriptList(BaseModel):
    items: list[ScriptResponse]
    total: int
    page: int
    page_size: int
