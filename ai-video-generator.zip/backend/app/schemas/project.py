from pydantic import BaseModel, Field


class ProjectCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    description: str | None = None
    project_type: str = "text-to-video"


class ProjectUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    status: str | None = None
    metadata: dict | None = None


class ProjectResponse(BaseModel):
    id: str
    user_id: str
    title: str
    description: str | None
    project_type: str
    status: str
    thumbnail_url: str | None
    metadata: dict = {}
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True


class ProjectList(BaseModel):
    items: list[ProjectResponse]
    total: int
    page: int
    page_size: int
