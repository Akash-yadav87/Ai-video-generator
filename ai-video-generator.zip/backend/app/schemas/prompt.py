from pydantic import BaseModel, Field


class PromptEnhanceRequest(BaseModel):
    raw_prompt: str = Field(min_length=3, max_length=5000)
    style: str = "cinematic"
    tone: str = "professional"


class PromptGenerateRequest(BaseModel):
    topic: str = Field(min_length=3, max_length=1000)
    style: str = "cinematic"
    tone: str = "dramatic"
    length: str = "medium"


class PromptSaveRequest(BaseModel):
    title: str | None = None
    raw_prompt: str
    enhanced_prompt: str | None = None
    category: str | None = None
    tags: list[str] | None = None


class PromptResponse(BaseModel):
    id: str
    title: str | None
    raw_prompt: str
    enhanced_prompt: str | None
    category: str | None
    tags: list[str] | None
    is_favorite: bool
    usage_count: int
    created_at: str

    class Config:
        from_attributes = True


class PromptList(BaseModel):
    items: list[PromptResponse]
    total: int
    page: int
    page_size: int
