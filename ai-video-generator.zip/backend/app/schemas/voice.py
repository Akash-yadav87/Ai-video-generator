from pydantic import BaseModel, Field


class VoiceGenerateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    voice_id: str | None = None
    provider: str = "elevenlabs"
    speed: float = 1.0
    pitch: float = 1.0


class VoiceProfileCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    voice_id: str | None = None
    provider: str = "elevenlabs"
    settings: dict | None = None
    is_public: bool = False


class VoiceProfileResponse(BaseModel):
    id: str
    name: str
    voice_id: str | None
    provider: str
    sample_url: str | None
    settings: dict = {}
    is_public: bool
    created_at: str

    class Config:
        from_attributes = True
