from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional


class VideoGenerationRequest(BaseModel):
    generation_type: str = Field(..., description="text-to-video, image-to-video, video-to-video")
    prompt: str = Field(..., min_length=3, max_length=5000)
    negative_prompt: str | None = None
    source_url: str | None = None
    duration: float = 5.0
    resolution: str = "1080p"
    project_id: str | None = None


class VideoGenerationResponse(BaseModel):
    id: str
    generation_type: str
    prompt: str
    enhanced_prompt: str | None
    source_url: str | None
    output_url: str | None
    status: str
    duration: float
    resolution: str
    metadata: dict = {}
    error_message: str | None
    created_at: str
    completed_at: str | None

    class Config:
        from_attributes = True


class VideoGenerationList(BaseModel):
    items: list[VideoGenerationResponse]
    total: int
    page: int
    page_size: int
