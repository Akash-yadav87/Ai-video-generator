from pydantic import BaseModel, Field


class CharacterCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str | None = None
    appearance: str | None = None
    personality: str | None = None
    reference_images: list[str] | None = None
    voice_id: str | None = None
    is_public: bool = False


class CharacterUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    appearance: str | None = None
    personality: str | None = None
    reference_images: list[str] | None = None
    voice_id: str | None = None
    is_public: bool | None = None
    consistency_data: dict | None = None


class CharacterResponse(BaseModel):
    id: str
    name: str
    description: str | None
    appearance: str | None
    personality: str | None
    avatar_url: str | None
    reference_images: list[str] | None
    voice_id: str | None
    is_public: bool
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True


class CharacterList(BaseModel):
    items: list[CharacterResponse]
    total: int
    page: int
    page_size: int
