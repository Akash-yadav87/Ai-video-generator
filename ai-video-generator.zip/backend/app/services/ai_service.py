"""AI Service - integrates with external AI APIs for video generation, prompts, scripts, and voice.

In production, replace simulation logic with actual API calls to OpenAI, Stability AI, Replicate, ElevenLabs, etc.
"""
import uuid
import random
from datetime import datetime, timezone
from app.models.models import VideoGeneration

# Style/tone presets for prompt enhancement
STYLE_MODIFIERS = {
    "cinematic": "cinematic lighting, 4k resolution, shallow depth of field, anamorphic lens",
    "anime": "anime art style, vibrant colors, cel shaded, 2D animation",
    "realistic": "photorealistic, hyperdetailed, 8k, natural lighting",
    "3d_render": "3D rendered, octane render, ray tracing, unreal engine 5",
    "watercolor": "watercolor painting style, artistic, flowing brushstrokes",
    "pixel_art": "pixel art style, retro gaming, 8-bit aesthetic",
}

TONE_MODIFIERS = {
    "dramatic": "high dramatic tension, emotional intensity",
    "professional": "professional, clean, corporate quality",
    "whimsical": "playful, magical, fantastical elements",
    "dark": "dark atmosphere, moody, low-key lighting",
    "uplifting": "inspirational, warm, hopeful atmosphere",
}


async def enhance_prompt(raw_prompt: str, style: str = "cinematic", tone: str = "professional") -> str:
    """Enhance a raw prompt with style and tone modifiers."""
    style_mod = STYLE_MODIFIERS.get(style, STYLE_MODIFIERS["cinematic"])
    tone_mod = TONE_MODIFIERS.get(tone, TONE_MODIFIERS["professional"])
    base = raw_prompt.strip()
    if not base.endswith("."):
        base += "."
    return f"{base} {style_mod}, {tone_mod}, high quality, professional video production."


async def generate_prompt(topic: str, style: str = "cinematic", tone: str = "dramatic", length: str = "medium") -> dict:
    """Generate AI video prompts based on a topic."""
    lengths = {"short": 2, "medium": 3, "long": 5}
    num_variants = lengths.get(length, 3)

    templates = [
        "A stunning {style} sequence showing {topic} in breathtaking detail, {tone} atmosphere.",
        "Professional video of {topic}, {style} style with {tone} undertones, masterfully composed.",
        "{style} footage capturing the essence of {topic} with {tone} emotional depth.",
        "Dynamic {style} video featuring {topic}, rich textures and {tone} storytelling.",
        "Artistic interpretation of {topic} in {style} aesthetics, {tone} visual narrative.",
    ]

    variants = []
    for i in range(min(num_variants, len(templates))):
        prompt_text = templates[i].format(topic=topic, style=style, tone=tone)
        variants.append({
            "index": i + 1,
            "prompt": prompt_text,
            "enhanced": await enhance_prompt(prompt_text, style=style, tone=tone),
        })

    return {"topic": topic, "style": style, "tone": tone, "variants": variants}


async def generate_script(premise: str, genre: str = "drama", num_scenes: int = 5, include_dialogue: bool = True, character_names: list | None = None) -> dict:
    """Generate a script with scenes and dialogue."""
    if not character_names:
        character_names = ["ALEX", "JORDAN", "SAM"]

    scene_templates = [
        {"location": "Urban Rooftop at Dusk", "time": "Evening", "mood": "Contemplative"},
        {"location": "Underground Laboratory", "time": "Night", "mood": "Tense"},
        {"location": "Coastal Boardwalk", "time": "Afternoon", "mood": "Hopeful"},
        {"location": "Abandoned Warehouse", "time": "Midnight", "mood": "Mysterious"},
        {"location": "Luxury Penthouse", "time": "Morning", "mood": "Elegant"},
        {"location": "Dense Forest Clearing", "time": "Dawn", "mood": "Ethereal"},
        {"location": "Futuristic City Street", "time": "Night", "mood": "Cyberpunk"},
        {"location": "Rustic Mountain Cabin", "time": "Sunset", "mood": "Intimate"},
        {"location": "Space Station Corridor", "time": "Artificial Day", "mood": "Isolated"},
        {"location": "Medieval Castle Hall", "time": "Night", "mood": "Epic"},
    ]

    dialogue_lines = [
        "We can't keep running forever.",
        "Do you trust me?",
        "This changes everything we thought we knew.",
        "I never wanted it to come to this.",
        "The truth is out there, waiting for us.",
        "Some secrets are better left buried.",
        "We have one shot at this.",
        "After everything we've been through...",
        "Look at what we've become.",
        "There has to be another way.",
    ]

    scenes = []
    for i in range(min(num_scenes, len(scene_templates))):
        template = scene_templates[i % len(scene_templates)]
        scene = {
            "scene_number": i + 1,
            "location": template["location"],
            "time": template["time"],
            "mood": template["mood"],
            "description": f"{template['mood']} scene at {template['location']}. The atmosphere is charged with {genre} tension. {premise[:100]}...",
            "dialogue": [] if not include_dialogue else [
                {
                    "character": character_names[j % len(character_names)],
                    "line": random.choice(dialogue_lines),
                    "direction": random.choice(["(intense)", "(whispering)", "(determined)", "(hesitant)", "(firm)", ""]),
                }
                for j in range(random.randint(2, 4))
            ],
        }
        scenes.append(scene)

    return {
        "title": f"Untitled {genre.title()} Script",
        "genre": genre,
        "premise": premise,
        "num_scenes": len(scenes),
        "scenes": scenes,
    }


async def generate_voice(text: str, voice_id: str | None = None, provider: str = "elevenlabs", speed: float = 1.0, pitch: float = 1.0) -> dict:
    """Generate voice audio from text. In production, calls ElevenLabs or similar API."""
    return {
        "audio_url": f"/uploads/voice/{uuid.uuid4().hex}.mp3",
        "text": text,
        "voice_id": voice_id or "default",
        "provider": provider,
        "duration_seconds": len(text.split()) * 0.4,
        "speed": speed,
        "pitch": pitch,
        "status": "completed",
    }


async def get_voice_preview(voice_id: str, provider: str = "elevenlabs") -> dict:
    """Get a preview of a voice."""
    return {
        "voice_id": voice_id,
        "provider": provider,
        "preview_url": f"/uploads/voice/preview_{voice_id}.mp3",
        "name": "Voice Preview",
    }


async def simulate_video_generation(generation: VideoGeneration, db) -> None:
    """Simulate video generation with a fake output. Replace with actual AI API calls."""
    generation.status = "processing"
    await db.commit()

    # Simulate processing time
    import asyncio
    await asyncio.sleep(0.1)

    generation.status = "completed"
    generation.output_url = f"/uploads/videos/{generation.id}.mp4"
    generation.completed_at = datetime.now(timezone.utc)
    generation.metadata = {
        **(generation.metadata or {}),
        "frames": 150,
        "fps": 30,
        "model": "ai-video-gen-v2",
        "seed": random.randint(1, 99999),
    }
    await db.commit()
